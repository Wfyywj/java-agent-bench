# Requirement decisions

## Provided business answers (not assumptions)
- Tenant-scoped token binds loan, equipment and damage. Exact successful replay must use the stored response, even after restart, and must not write another event or job. Any bound-field change conflicts.
- Unknown loan and tenant mismatch both return `404 NOT_FOUND`. First-use equipment mismatch, AVAILABLE or RETIRED loans are `409 NOT_RETURNABLE`.
- First normal return persists CLEANING and one cleaning job. Damaged returns persist REVIEW and no cleaning job; no automatic availability transition exists.
- Loan, event and job publication is atomic. Each injected staged failure returns `503 RETRY_LATER`, with no published changes.
- One process/writer with two independent HTTP connections is the supported concurrency model. File snapshots are the supplied adapter; SQL infrastructure acceptance is explicitly outside scope.

## Implementation choices / assumptions
- Where predicates overlap, ownership/nonexistence is checked first to preserve non-disclosure. Thus a token submitted against an unknown or foreign-tenant loan returns 404, rather than exposing token history. Changed loan binding within the authorized tenant returns TOKEN_CONFLICT.
- For an owned loan, token replay/conflict precedes lifecycle and equipment checks. This permits replay from CLEANING and REVIEW and ensures changed payload is TOKEN_CONFLICT, not NOT_RETURNABLE.
- Without a prior token, only BORROWED is returnable; a different token cannot re-return CLEANING or REVIEW. This follows the unborrowed rule and task metadata's second-token rejection expectation.
- The existing service monitor is the single writer boundary. It covers validation, snapshot staging, file replacement and live-state refresh. This is not multi-process locking.
- Preserve the existing snapshot format, HTTP/public types, parser and commit adapter. Existing corrupt/duplicate historical snapshots are not automatically repaired: choosing which cleaning job to delete is outside the supplied contract.
- No clarification required: the frozen answers and public metadata are sufficient for this scoped repair.
