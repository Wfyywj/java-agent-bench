"""Local HTTP/snapshot regression evidence, not SQL infrastructure acceptance."""
import concurrent.futures
import http.client
from pathlib import Path
import shutil
import subprocess
import tempfile
import threading
import unittest
import urllib.parse

ROOT = Path(__file__).resolve().parents[1]


class Returns(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.build = tempfile.TemporaryDirectory(dir=ROOT / 'regression-tests')
        subprocess.run(['java', 'com.sun.tools.javac.Main', '-d', cls.build.name,
                        *map(str, sorted((ROOT / 'src').glob('*.java')))], check=True)

    @classmethod
    def tearDownClass(cls):
        cls.build.cleanup()

    def setUp(self):
        self.work = tempfile.TemporaryDirectory(dir=ROOT / 'regression-tests')
        self.snapshot = Path(self.work.name) / 'store.tsv'
        shutil.copyfile(ROOT / 'evidence/seed.tsv', self.snapshot)
        self.start()

    def start(self):
        self.process = subprocess.Popen(
            ['java', '-Xmx96m', '-cp', self.build.name, 'App', str(self.snapshot)],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        self.port = int(self.process.stdout.readline().strip())

    def stop(self):
        self.process.terminate()
        self.process.communicate(timeout=10)

    def restart(self):
        self.stop()
        self.start()

    def tearDown(self):
        self.stop()
        self.work.cleanup()

    def post(self, fault=0, **changes):
        fields = dict(tenant='tenantA', loan='loan1', token='cabinet77',
                      equipment='bat1', damaged='false')
        fields.update(changes)
        connection = http.client.HTTPConnection('127.0.0.1', self.port, timeout=5)
        try:
            connection.request('POST', '/returns', urllib.parse.urlencode(fields),
                               {'Content-Type': 'application/x-www-form-urlencoded',
                                'X-Test-Fault': str(fault)})
            response = connection.getresponse()
            return response.status, response.read().decode()
        finally:
            connection.close()

    def rows(self, kind):
        return [r.split('\t') for r in self.snapshot.read_text().splitlines()
                if r.startswith(kind + '\t')]

    def assert_returned(self, state='CLEANING', events=1, jobs=1):
        self.assertEqual(next(r[4] for r in self.rows('L') if r[1]=='loan1'), state)
        self.assertEqual(len(self.rows('E')), events)
        self.assertEqual(len(self.rows('C')), jobs)

    def test_A01_replay_restart_and_second_token(self):
        expected = (200, 'loan=loan1;state=CLEANING')
        self.assertEqual(self.post(), expected)
        committed = self.snapshot.read_bytes()
        self.assertEqual(self.post(), expected)
        self.assertEqual(self.snapshot.read_bytes(), committed)
        self.restart()
        self.assertEqual(self.post(), expected)
        self.assertEqual(self.post(token='new'), (409, 'NOT_RETURNABLE'))
        self.assertEqual(self.snapshot.read_bytes(), committed)
        self.assert_returned()

    def test_A02_payload_binding_and_tenant_scope(self):
        self.assertEqual(self.post()[0], 200)
        committed = self.snapshot.read_bytes()
        for changes in [dict(equipment='ball2'), dict(damaged='true'),
                        dict(loan='loan2', equipment='ball2')]:
            self.assertEqual(self.post(**changes), (409, 'TOKEN_CONFLICT'))
        self.assertEqual(self.snapshot.read_bytes(), committed)
        self.restart()
        self.assertEqual(self.post(damaged='true'), (409, 'TOKEN_CONFLICT'))
        self.assertEqual(self.post(tenant='tenantB', loan='loan3', equipment='mat3'),
                         (200, 'loan=loan3;state=CLEANING'))
        self.assertEqual(len(self.rows('E')), 2)
        self.assertEqual(len(self.rows('C')), 2)

    def test_A03_all_staged_failures_leave_no_effects(self):
        initial = self.snapshot.read_bytes()
        for damaged in ('false', 'true'):
            for fault in (1, 2, 3):
                with self.subTest(fault=fault, damaged=damaged):
                    self.assertEqual(self.post(fault=fault, damaged=damaged),
                                     (503, 'RETRY_LATER'))
                    self.assertEqual(self.snapshot.read_bytes(), initial)
                    # Retry without restart detects accidental changes in live state.
                    state = 'REVIEW' if damaged == 'true' else 'CLEANING'
                    expected = (200, 'loan=loan1;state=' + state)
                    self.assertEqual(self.post(damaged=damaged), expected)
                    self.assert_returned(state, jobs=0 if damaged == 'true' else 1)
                    self.restart()
                    self.assertEqual(self.post(damaged=damaged), expected)
                    self.stop()
                    self.snapshot.write_bytes(initial)
                    self.start()

    def test_A04_tenant_lifecycle_and_equipment(self):
        initial = self.snapshot.read_bytes()
        for changes in [dict(tenant='tenantB'), dict(loan='unknown'),
                        dict(loan='loan3', equipment='mat3')]:
            self.assertEqual(self.post(**changes), (404, 'NOT_FOUND'))
        for changes in [dict(loan='loan4', equipment='cone4'),
                        dict(loan='loan5', equipment='net5'),
                        dict(equipment='ball2'), dict(equipment='ball2', damaged='true')]:
            self.assertEqual(self.post(**changes), (409, 'NOT_RETURNABLE'))
        self.assertEqual(self.snapshot.read_bytes(), initial)
        self.restart()
        self.assertEqual(self.snapshot.read_bytes(), initial)
        self.assertEqual(self.post(), (200, 'loan=loan1;state=CLEANING'))
        self.restart()
        self.assertEqual(self.post(), (200, 'loan=loan1;state=CLEANING'))
        self.assert_returned()

    def test_A05_two_connections_and_damaged_review(self):
        barrier = threading.Barrier(2)
        def request():
            barrier.wait(timeout=5)
            return self.post()
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            replies = list(pool.map(lambda _: request(), range(2)))
        self.assertEqual(replies, [(200, 'loan=loan1;state=CLEANING')] * 2)
        self.assert_returned()
        damaged = dict(loan='loan2', equipment='ball2', token='damaged', damaged='true')
        self.assertEqual(self.post(**damaged), (200, 'loan=loan2;state=REVIEW'))
        committed = self.snapshot.read_bytes()
        self.restart()
        self.assertEqual(self.post(**damaged), (200, 'loan=loan2;state=REVIEW'))
        self.assertEqual(self.post(**dict(damaged, token='other')), (409, 'NOT_RETURNABLE'))
        self.assertEqual(self.snapshot.read_bytes(), committed)
        self.assertEqual(next(r[4] for r in self.rows('L') if r[1]=='loan2'), 'REVIEW')
        self.assertEqual(self.rows('C'), [['C', 'loan1']])


if __name__ == '__main__':
    unittest.main(verbosity=2)
