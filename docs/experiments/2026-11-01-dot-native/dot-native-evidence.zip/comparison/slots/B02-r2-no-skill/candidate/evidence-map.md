# Evidence map

All supplied evidence is synthetic/public, not production data.

| Evidence | Finding | Repair / regression |
|---|---|---|
| `evidence/incident.log` | Lost response causes same-token retry; two jobs but one event | Stored event was loaded but ignored; event map overwrite masked repeated append to cleaning list. Return stored response without staging anything. A01 |
| `evidence/seed.tsv` | Two tenantA borrowed loans, one tenantB borrowed loan, AVAILABLE and RETIRED states | Exercise tenant isolation, token scoping, payload mismatch, nonreturnable lifecycle and wrong equipment. A02/A04 |
| `evidence/schema.sql` | Planned `(tenant,token)` event uniqueness; loan-key cleaning uniqueness; all writes in one transaction | Tenant-token lookup plus serialized first-return gate prevents duplicates in local adapter. Not proof of SQL constraints. A01/A03/A05 |
| `src/ReturnService.java` (original boundary) | Method synchronized; previous event unused; CLEANING allowed as fresh return; copy staged before commit | Replay/conflict gate, then BORROWED-only first-return gate; retain staged write failures. A01–A05 |
| `src/Store.java` | Disk snapshot reload; copied collections; atomic replacement before refreshing live state | Preserve durability mechanism and validate disk contents and restart behavior. A01/A03/A04/A05 |
| `src/App.java` | Four HTTP worker threads; test failure translated to 503 | Two separate client connections and injected failure response assertions. A03/A05 |

## Runnable checks
`python3 candidate/regression-tests/test_returns.py` from the slot directory (or `python3 regression-tests/test_returns.py` from candidate).

- B02-A01: `test_A01_replay_restart_and_second_token`: exact response, byte-identical snapshot on replay, restart, persisted CLEANING, second-token rejection, one event/job.
- B02-A02: `test_A02_payload_binding_and_tenant_scope`: equipment, damage and authorized-loan conflicts; restart conflict; same token valid in another tenant.
- B02-A03: `test_A03_all_staged_failures_leave_no_effects`: stages 1–3 for normal and damaged returns, unchanged snapshot, immediate retry, complete state/event/job, durable replay after restart.
- B02-A04: `test_A04_tenant_lifecycle_and_equipment`: indistinguishable tenant/unknown failures, AVAILABLE/RETIRED, wrong equipment for both damage values; unchanged full snapshot across restart, same-token corrected return, durable replay.
- B02-A05: `test_A05_two_connections_and_damaged_review`: concurrent identical normal requests yield one event/job; damaged REVIEW survives restart/replay and rejects fresh token, no damaged cleaning job.

A03/A05 are local-adapter evidence only: no PostgreSQL transaction, SQL unique constraints, two database connections, fsync/power-loss guarantees or multi-process locks are measured.
