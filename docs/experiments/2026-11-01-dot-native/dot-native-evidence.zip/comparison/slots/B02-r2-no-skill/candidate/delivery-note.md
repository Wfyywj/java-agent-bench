# Delivery note

## Changes
- `src/ReturnService.java`: check persisted token payload and replay stored response before lifecycle checks; only BORROWED loans accept first returns. Existing ownership, staged atomic publication and synchronization remain.
- Added `regression-tests/test_returns.py`, `requirement-decisions.md`, `evidence-map.md`, and this note.
- Public input files, model, HTTP adapter and storage format unchanged. No migration or dependency added.

## Validation
Run `python3 regression-tests/test_returns.py` from candidate. The suite compiles all source into a temporary directory inside regression-tests, starts isolated loopback servers and removes its artifacts.

Initial test invocation found no `javac` executable on PATH. Java 21 includes `jdk.compiler`, so the runner invokes `java com.sun.tools.javac.Main` instead; no installation needed. Five mapped HTTP regression tests passed after that adjustment. Final expanded suite also passed all five tests, checking all three faults for both normal and damaged returns.

## Rollback
Stop the service before replacing compiled classes. Restore the original ReturnService.java/build from the owner's source control and rebuild/restart using the same snapshot path; the disk format is unchanged. Reverting reintroduces duplicate-return behavior, so block writes until a replacement fix is available. Do not revert successful loan data or erase event history to roll back code. Preserve a stopped-service snapshot backup before deployment. Historical duplicate jobs require separate authorized reconciliation, not this patch.

## Unverified / limitations
No evaluator, reference, mutants or selfchecks were available or used. No PostgreSQL, SQL unique constraints, multi-process/multi-service writers, crash/power-loss/fsync, or deployment acceptance is claimed. Atomic replacement relies on the existing filesystem's ATOMIC_MOVE support; errors remain 503. Invalid/corrupt legacy snapshot recovery, existing duplicate cleanup, production authorization for the local test header and long-running automatic inventory workflows are outside this fixture.
