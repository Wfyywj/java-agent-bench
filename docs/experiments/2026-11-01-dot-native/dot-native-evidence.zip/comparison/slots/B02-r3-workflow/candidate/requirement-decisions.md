# Requirement decisions

## Supplied answers
The frozen contract in PROMPT.md defines tenant-scoped durable token binding to loan, equipment and damage; exact replay returns the stored original success without writes. Changed authorized payload conflicts. Unknown or other-tenant loan requests are indistinguishable 404s. Only BORROWED equipment can begin a new return. Normal returns enter CLEANING with one job; damaged returns enter REVIEW with none. All three writes publish atomically and faults 1–3 leave no effects. Single process/writer supports concurrent HTTP requests.

## Scope and acceptance
Repair the service, retain the snapshot adapter and HTTP/public model API, and add offline regressions. Exercise success, replay/restart, changed fields, tenant privacy, invalid equipment/state, damaged flow, injected rollback/retry and independent concurrent connections. No PostgreSQL, fsync/crash guarantees, multiple writers, or automatic availability worker is added.

## Decisions inferred from supplied code/contract
Check loan visibility before token replay/conflict to preserve the mandatory indistinguishable 404 even when a token exists. Then check the complete stored token payload before returnability, so CLEANING and REVIEW exact replays succeed but new tokens on these states fail. The existing validated identifier alphabet makes tenant/token slash keys unambiguous at the HTTP boundary. Existing snapshots are assumed well-formed; historical duplicate repair is outside this request. No unresolved business clarification blocks implementation.
