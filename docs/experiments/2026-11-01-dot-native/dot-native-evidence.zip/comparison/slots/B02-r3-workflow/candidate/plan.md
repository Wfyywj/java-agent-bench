# Plan
When the cabinet retries a lost response, first confirm it can see the requested loan. Look up its tenant-scoped token. If all bound fields match, send back the stored response immediately; if any differ, reject without writing. For a new token, accept only the loan's own equipment in BORROWED state. This prevents both replay-generated jobs and second-token returns.

Change only ReturnService's validation/replay branch. Keep Store's copy-and-atomic-rename publication and the service synchronization, so two connections cannot validate against the same stale state. No in-memory-only cache or SQL integration is needed. Preserve the HTTP contract and stored event format.

Build Python standard-library HTTP tests compiling the supplied Java sources into a temporary candidate-local directory. Verify response bodies and complete on-disk snapshots, including restart, conflicts, all fault stages, unavailable states, privacy, normal/damaged returns and simultaneous connections. Run the tests against the original code first to demonstrate a regression, then against the change. Review validation ordering and write boundaries before local delivery.
