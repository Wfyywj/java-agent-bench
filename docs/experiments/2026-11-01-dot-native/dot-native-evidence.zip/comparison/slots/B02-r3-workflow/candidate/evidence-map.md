# Evidence map

All inputs are supplied synthetic fixtures, not production evidence. Regression names refer to regression-tests/test_returns.py; results are in regression-tests/after.txt.

| Acceptance | Provided evidence and implementation | Regression evidence |
|---|---|---|
| B02-A01 | incident.log: retry duplicates jobs; ReturnService now returns durable prior.result before staging. Store loads E rows on restart. | test_A01_replay_restart_and_new_token: response equality, unchanged full snapshot, restart and one event/job; A04 corrected return also replays. |
| B02-A02 | schema.sql binds tenant/token and payload; service compares loan/equipment/damaged. | test_A02_binding_and_tenant_scope: each changed field conflicts without writes, restart preserves binding, other tenant may use same token. |
| B02-A03 | schema.sql calls for transaction; unchanged Store copy/rename adapter and service fail points implement local atomic publication. | test_A03_all_staged_failures: stages 1–3, normal/damaged, 503, unchanged snapshot after restart, individual successful retries. Local-adapter evidence only. |
| B02-A04 | seed.tsv provides tenant mismatch, AVAILABLE and RETIRED; service checks visibility and loan equipment before writes. | test_A04_invalid_state_and_privacy plus test_A04_wrong_equipment_does_not_bind_token: uniform 404, invalid lifecycle, equipment mismatch with either damage flag, unchanged disk across restart, corrected same-token success. |
| B02-A05 | synchronized service serializes one writer; damaged branch remains REVIEW with no job. | test_A05_concurrent_normal and test_A05_concurrent_damaged_replay: independent HTTP connections released by barrier, exact replies, one event, one/zero jobs, REVIEW restart/replay. No database unique-constraint proof. |

Scope: no PostgreSQL, fsync/power-loss simulation, multi-process writer or automatic-availability worker tests. The planned schema was read, not executed. The unavailable benchmark verifier/selfcheck was not used.
