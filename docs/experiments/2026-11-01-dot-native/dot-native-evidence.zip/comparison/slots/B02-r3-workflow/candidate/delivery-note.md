# Local delivery

## Changes
- src/ReturnService.java now uses durable tenant/token replay, compares all bound payload fields, and only starts fresh returns from BORROWED. Public API, response strings and snapshot format are unchanged.
- requirement-decisions.md separates supplied business answers from ordering/fixture assumptions.
- plan.md, evidence-map.md and workflow-trace.md record the six-stage work and review-driven verification improvements.
- regression-tests/ contains seven HTTP regression methods mapped to B02-A01–A05 and recorded results.

## Verification
`python3 candidate/regression-tests/test_returns.py` from the slot root: **7 tests passed**, exit 0, 13.131 seconds. Java 21 compiled via `java com.sun.tools.javac.Main`; no dependencies installed. Checked response bodies, persisted states and event/job cardinality, exact snapshots, restart, every fault stage and retry, changed payloads, tenant privacy, wrong equipment, unavailable/retired loans, concurrent connections and damaged review. Python AST parsing also passed. The first baseline attempt was blocked by a missing javac launcher, not a demonstrated behavioral failure.

## Rollback
Stop the process, preserve the current snapshot backup, and restore the supplied original src/ReturnService.java before rebuilding. No data-format migration is needed. The old service reintroduces duplicate-return behavior, so disable return traffic during rollback. Historical duplicate jobs/events are not repaired by this patch; restoring a snapshot requires separate operational authorization and reconciliation to avoid discarding valid returns.

## Unverified / excluded
No supplied verifier or selfcheck was available or run. No CI, PostgreSQL transaction, SQL uniqueness, two database connections, fsync/power-loss durability or multi-process locking was verified. B02-A03 and A05 have local single-writer snapshot evidence only. No automatic availability worker exists in this adapter; tests establish durable REVIEW and no cleaning job, not a production worker's behavior. Original supplied inputs were not edited. Delivery is local only; nothing committed, pushed or published.
