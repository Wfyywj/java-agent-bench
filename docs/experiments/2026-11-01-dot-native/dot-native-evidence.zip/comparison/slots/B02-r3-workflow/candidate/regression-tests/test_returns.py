"""Offline B02 HTTP regressions; python3 regression-tests/test_returns.py."""
import concurrent.futures
import http.client
from pathlib import Path
import subprocess
import tempfile
import threading
import unittest
import urllib.parse

ROOT = Path(__file__).resolve().parents[1]

class Returns(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.build = tempfile.TemporaryDirectory(dir=ROOT)
        subprocess.run(['java', 'com.sun.tools.javac.Main', '-d', cls.build.name, *map(str, (ROOT/'src').glob('*.java'))], check=True)

    @classmethod
    def tearDownClass(cls):
        cls.build.cleanup()

    def setUp(self):
        self.work = tempfile.TemporaryDirectory(dir=ROOT)
        self.db = Path(self.work.name)/'store.tsv'
        self.db.write_bytes((ROOT/'evidence/seed.tsv').read_bytes())
        self.start()

    def start(self):
        self.proc = subprocess.Popen(['java', '-Xmx96m', '-cp', self.build.name, 'App', str(self.db)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        self.port = int(self.proc.stdout.readline())

    def stop(self):
        self.proc.terminate()
        self.proc.communicate(timeout=10)

    def restart(self):
        self.stop()
        self.start()

    def tearDown(self):
        self.stop()
        self.work.cleanup()

    def request(self, fault=None, **changes):
        payload = dict(tenant='tenantA', loan='loan1', token='cabinet77', equipment='bat1', damaged='false')
        payload.update(changes)
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        if fault is not None:
            headers['X-Test-Fault'] = str(fault)
        connection = http.client.HTTPConnection('127.0.0.1', self.port, timeout=10)
        try:
            connection.request('POST', '/returns', urllib.parse.urlencode(payload), headers)
            response = connection.getresponse()
            return response.status, response.read().decode()
        finally:
            connection.close()

    def assert_state(self, state, jobs, events=1):
        rows = [line.split('\t') for line in self.db.read_text().splitlines()]
        self.assertEqual([r[4] for r in rows if r[:2] == ['L', 'loan1']], [state])
        self.assertEqual(sum(r[0] == 'C' for r in rows), jobs)
        self.assertEqual(sum(r[0] == 'E' for r in rows), events)

    def test_A01_replay_restart_and_new_token(self):
        expected = (200, 'loan=loan1;state=CLEANING')
        self.assertEqual(self.request(), expected)
        saved = self.db.read_bytes()
        self.assertEqual(self.request(), expected)
        self.assertEqual(self.db.read_bytes(), saved)
        self.restart()
        self.assertEqual(self.request(), expected)
        self.assertEqual(self.request(token='different'), (409, 'NOT_RETURNABLE'))
        self.assertEqual(self.db.read_bytes(), saved)
        self.assert_state('CLEANING', 1)

    def test_A02_binding_and_tenant_scope(self):
        self.assertEqual(self.request()[0], 200)
        saved = self.db.read_bytes()
        for change in [dict(equipment='ball2'), dict(damaged='true'), dict(loan='loan2', equipment='ball2')]:
            with self.subTest(change=change):
                self.assertEqual(self.request(**change), (409, 'TOKEN_CONFLICT'))
                self.assertEqual(self.db.read_bytes(), saved)
        self.restart()
        self.assertEqual(self.request(damaged='true'), (409, 'TOKEN_CONFLICT'))
        self.assertEqual(self.request(tenant='tenantB', loan='loan3', equipment='mat3'), (200, 'loan=loan3;state=CLEANING'))

    def test_A03_all_staged_failures(self):
        original = self.db.read_bytes()
        for damaged in ['false', 'true']:
            for stage in [1, 2, 3]:
                with self.subTest(damaged=damaged, stage=stage):
                    self.assertEqual(self.request(fault=stage, damaged=damaged), (503, 'RETRY_LATER'))
                    self.assertEqual(self.db.read_bytes(), original)
                    self.restart()
                    self.assertEqual(self.db.read_bytes(), original)
                    state = 'REVIEW' if damaged == 'true' else 'CLEANING'
                    self.assertEqual(self.request(damaged=damaged), (200, 'loan=loan1;state='+state))
                    self.assert_state(state, 0 if damaged == 'true' else 1)
                    self.stop()
                    self.db.write_bytes(original)
                    self.start()

    def test_A04_invalid_state_and_privacy(self):
        original = self.db.read_bytes()
        for change, result in [
            (dict(tenant='tenantB'), (404, 'NOT_FOUND')),
            (dict(loan='missing'), (404, 'NOT_FOUND')),
            (dict(loan='loan4', equipment='cone4'), (409, 'NOT_RETURNABLE')),
            (dict(loan='loan5', equipment='net5'), (409, 'NOT_RETURNABLE'))]:
            self.assertEqual(self.request(**change), result)
            self.assertEqual(self.db.read_bytes(), original)
        self.assertEqual(self.request()[0], 200)
        self.assertEqual(self.request(loan='loan3', equipment='mat3'), (404, 'NOT_FOUND'))
        self.assertEqual(self.request(loan='missing'), (404, 'NOT_FOUND'))

    def test_A04_wrong_equipment_does_not_bind_token(self):
        for damaged in ['false', 'true']:
            with self.subTest(damaged=damaged):
                original = self.db.read_bytes()
                self.assertEqual(self.request(equipment='wrong', damaged=damaged), (409, 'NOT_RETURNABLE'))
                self.assertEqual(self.db.read_bytes(), original)
                self.restart()
                self.assertEqual(self.db.read_bytes(), original)
        self.assertEqual(self.request()[0], 200)
        self.restart()
        self.assertEqual(self.request(), (200, 'loan=loan1;state=CLEANING'))
        self.assert_state('CLEANING', 1)

    def concurrent(self, **kwargs):
        barrier = threading.Barrier(2)
        def submit():
            barrier.wait(timeout=10)
            return self.request(**kwargs)
        with concurrent.futures.ThreadPoolExecutor(2) as pool:
            return list(pool.map(lambda _: submit(), range(2)))

    def test_A05_concurrent_normal(self):
        self.assertEqual(self.concurrent(), [(200, 'loan=loan1;state=CLEANING')]*2)
        self.assert_state('CLEANING', 1)

    def test_A05_concurrent_damaged_replay(self):
        expected = (200, 'loan=loan1;state=REVIEW')
        self.assertEqual(self.concurrent(damaged='true'), [expected]*2)
        saved = self.db.read_bytes()
        self.restart()
        self.assertEqual(self.request(damaged='true'), expected)
        self.assertEqual(self.request(damaged='true', token='new'), (409, 'NOT_RETURNABLE'))
        self.assertEqual(self.db.read_bytes(), saved)
        self.assert_state('REVIEW', 0)

if __name__ == '__main__':
    unittest.main(verbosity=2)
