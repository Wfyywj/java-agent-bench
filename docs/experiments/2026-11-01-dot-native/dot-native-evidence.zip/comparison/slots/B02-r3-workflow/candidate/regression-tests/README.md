# Local HTTP regressions

From candidate/: `python3 regression-tests/test_returns.py`.
Requires Java 21 with jdk.compiler and Python 3 standard library. Compilation uses `java com.sun.tools.javac.Main` because this environment lacks a standalone javac launcher. Tests use temporary directories under candidate/, launch loopback App processes, and preserve all supplied evidence files. No downloads or benchmark tools are involved.

Seven test methods cover B02-A01 through B02-A05; see ../evidence-map.md. before.txt records the original blocked compiler-launch attempt (not a behavioral regression failure). after.txt records the final reviewed test run.
