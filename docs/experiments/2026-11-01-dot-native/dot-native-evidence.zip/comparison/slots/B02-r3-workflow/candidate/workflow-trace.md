# Workflow trace

## 1. clarify-task
Read PROMPT.md, task.json, all four Java files, incident.log, seed.tsv and schema.sql. Incident identifies two jobs but one overwritten event; ReturnService reads `previous` without using it and allows CLEANING as a fresh return. Store stages copies then atomically renames the snapshot; App serializes through one service lock across HTTP workers. Recorded contract, privacy ordering and exclusions in requirement-decisions.md. No blocking question: frozen business answers suffice.

## 2. plain-plan
Wrote plan.md describing the cabinet retry, visible-loan check, full durable replay binding and BORROWED-only fresh return. Selected a small service change rather than replacing the existing atomic snapshot adapter. Defined HTTP plus disk/restart regression evidence and kept PostgreSQL and multi-writer guarantees explicitly out of scope.

## 3. implement-slice
Added seven standard-library HTTP regression methods mapped to all five IDs, with candidate-local temporary compilation/store files. Original-code execution attempt failed before running tests: `javac` is absent from PATH (recorded in regression-tests/before.txt); this is infrastructure failure, not a demonstrated red behavioral test. Modified only ReturnService.java: compare prior loan/equipment/damage, return stored response on exact match, reject conflicts, and require BORROWED on new tokens. Existing service lock and Store transaction publication remain intact. No Git inspection outside candidate was performed because the supplied slot is restricted and has no candidate-local Git metadata.

## 4. verify-change
Ran `python3 candidate/regression-tests/test_returns.py` after implementation: exit 5, zero HTTP tests executed because `javac` is not found; full output in regression-tests/after.txt. JAVA_HOME is unset. Parsed the Python suite with `ast.parse`: passed. Runtime Java compilation and acceptance remain unverified; no unavailable benchmark/selfcheck was run and no dependency was installed. Manually traced the service's early returns: replay and conflict occur before any copied mutation, privacy before event lookup, and new requests require BORROWED.

## 5. review-change
Reviewed ReturnService against unchanged App/Store/Model: complete token binding, privacy ordering, damaged replay, BORROWED gate and synchronized commit remain correct by inspection. No confirmed service defect found. Review found two verification gaps: the missing executable does not imply an absent compiler module, and A03 initially only retried successfully after the combined failure sequence. `java --list-modules` showed jdk.compiler, and `java com.sun.tools.javac.Main -version` reported 21.0.12.1. Updated the test compiler launcher accordingly, and strengthened A03 to assert successful retry and persisted state/jobs separately after each normal/damaged fault, resetting only the temporary test fixture between cases. These are review-driven test changes, not relaxed assertions. Reverification follows.

### Reverification after review
Ran `python3 candidate/regression-tests/test_returns.py` using the compiler module: all seven methods passed, exit 0 (13.131 s), including the strengthened fault/retry matrix. Java 21 compilation therefore succeeded. Final output: regression-tests/after.txt. Initial compiler-path blocker is resolved. The original baseline was not behaviorally rerun, so before.txt must not be represented as red regression evidence. Evidence-map.md connects each public acceptance ID to its fixtures, implementation and tests.

## 6. deliver-change
Re-read the local-only delivery instructions and final service/test files. Delivered the service change, requirements/assumptions, plan, evidence map, seven-test suite with recorded outputs, this trace and delivery-note.md. All seven locally authored tests passed on the reviewed version; no benchmark result or full infrastructure acceptance is claimed. No commit, push, PR, CI, publication, memory or external action was requested or performed. Rollback and remaining infrastructure gaps are documented.
