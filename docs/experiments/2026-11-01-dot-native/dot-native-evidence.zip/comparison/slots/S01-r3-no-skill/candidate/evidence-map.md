# Evidence map

| Acceptance | Implementation evidence | Regression evidence |
| --- | --- | --- |
| S01-A01 | RefundService terminal/stale guards | test_A01_A02_success_terminal_once |
| S01-A02 | receipt check precedes state logic; conflict branch preserves projection; ledger updated only on first transition to success | test_A01_A02_success_terminal_once; test_A02_conflicts_ignore_order; test_concurrent_duplicates |
| S01-A03 | Signature.valid runs before writes; Main outputs only compact status; signature implementation unchanged | test_A03_A05_validation_no_write compares persisted bytes |
| S01-A04 | staged snapshot restored on before fault; a single Store.commit includes receipt/status/ledger/review; common after-fault return | test_A04_success_restart_faults; test_A04_review_restart_faults; test_A05_cancellation_success_and_stale_receipts |
| S01-A05 | cancellation is nonterminal; ordering/validation unchanged | test_A05_cancellation_success_and_stale_receipts; test_A03_A05_validation_no_write |

Store's existing process file lock covers loading through commit and shutdown;
its existing atomic rename replaces the entire snapshot. Independent JVM concurrent
replays validate process-level serialization on this filesystem, not a distributed
transaction guarantee. Restart tests rule out an in-memory-only deduplication fix.
Two distinct success sequences rule out deduplication alone as a solution to billing.
Old conflicting terminal evidence is reviewed before stale suppression, ruling out
blind max-sequence overwrite. No full signatures or fixture key are logged.

Executed: seven unittest methods passed under OpenJDK 21.0.12.1. Tests use only
synthetic data. Trusted benchmark selfcheck, hidden oracle, external systems, power
loss and unsupported-filesystem behavior were not executed.
