# Delivery

Changed src/bench/RefundService.java only in the implementation. Added requirement
decisions, evidence map and regression-tests/test_refunds.py. Public input files,
Main, Store and Signature are unchanged. No dependencies or network are needed.

Replay from candidate/: `python3 regression-tests/test_refunds.py`.
The runner compiles with the installed Java compiler module and creates temporary
build/state directories inside regression-tests/, removed after execution. All
seven tests passed, including fresh-process retries and eight concurrent replays.
The first attempt failed before tests because the javac launcher was absent;
using `java -m jdk.compiler/com.sun.tools.javac.Main` resolved that environment issue.

Behavior changes: terminal status protection, exactly-once ledger projection across
distinct success events, durable ignored-event receipts, uniform fault injection on
review/stale paths, and restoration of uncommitted in-memory state.

Existing properties files remain compatible; no migration is required. To roll
back code, stop consumers and restore the prior source/build. Preserve state and
receipts: deleting them enables duplicate effects. Reverting code reintroduces the
original regressions. Existing already-corrupted projections are not repaired.

Residual limits: atomic rename support is required. There is no fsync/power-loss
promise, database/distributed delivery, tenant field, real payment dispatch or
production secret handling. No external or hidden acceptance tests were run. The
local tests are evidence for the documented fixture, not production certification.
