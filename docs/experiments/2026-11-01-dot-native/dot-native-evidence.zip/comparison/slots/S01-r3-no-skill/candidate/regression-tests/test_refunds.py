"""Synthetic subprocess regressions: every CLI operation starts a fresh JVM."""
import hashlib, hmac, pathlib, subprocess, tempfile, unittest
ROOT = pathlib.Path(__file__).resolve().parents[1]

class RefundTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.build = tempfile.TemporaryDirectory(dir=ROOT / 'regression-tests')
  subprocess.run(['java', '-m', 'jdk.compiler/com.sun.tools.javac.Main', '-d', cls.build.name, *map(str, (ROOT/'src/bench').glob('*.java'))], check=True)
 @classmethod
 def tearDownClass(cls): cls.build.cleanup()
 def setUp(self):
  self.tmp = tempfile.TemporaryDirectory(dir=ROOT/'regression-tests')
  self.addCleanup(self.tmp.cleanup)
  self.assertEqual(self.cli('init'), '200 initialized')
 def cli(self, *args):
  return subprocess.check_output(['java','-cp',self.build.name,'bench.Main',self.tmp.name,*args],text=True).strip()
 def cb(self, seq, state, fault='none', id='r1', bad=False):
  seq=str(seq)
  sig=hmac.new(b'fixture-only-not-production',f'{id}|{seq}|{state}'.encode(),hashlib.sha256).hexdigest()
  return self.cli('callback',id,seq,state,'bad' if bad else sig,fault)
 def state(self, expected): self.assertEqual(self.cli('get','r1'),expected)
 def test_A01_A02_success_terminal_once(self):
  self.cb(1,'SUCCEEDED')
  self.cb(2,'PROCESSING'); self.cb(3,'CANCELLED'); self.cb(4,'SUCCEEDED')
  self.state('SUCCEEDED|1|false')
  self.assertEqual(self.cb(4,'SUCCEEDED'),'200 duplicate')
  self.assertEqual(self.cb(4,'FAILED'),'409 event_conflict')
  self.state('SUCCEEDED|1|false')
 def test_A02_conflicts_ignore_order(self):
  for first,second,ledger in [('SUCCEEDED','FAILED',1),('FAILED','SUCCEEDED',0)]:
   with self.subTest(first=first):
    self.cb(10,first,id='r2')
    self.assertEqual(self.cb(1,second,id='r2'),'409 manual_review')
    self.assertEqual(self.cli('get','r2'),f'{first}|{ledger}|true')
    # A separate fresh aggregate/store for the other direction.
    self.tmp.cleanup(); self.tmp=tempfile.TemporaryDirectory(dir=ROOT/'regression-tests')
    self.addCleanup(self.tmp.cleanup); self.cli('init')
 def test_A03_A05_validation_no_write(self):
  path=pathlib.Path(self.tmp.name)/'state.properties'; before=path.read_bytes()
  self.assertEqual(self.cb(1,'SUCCEEDED',bad=True),'401 invalid_signature')
  self.assertEqual(self.cb('','SUCCEEDED'),'422 invalid_sequence')
  self.assertEqual(self.cb(0,'SUCCEEDED'),'422 invalid_sequence')
  self.assertEqual(self.cb(1,'OTHER'),'422 invalid_state')
  self.assertEqual(self.cb(1,'SUCCEEDED',id='unknown'),'404 unknown_refund')
  self.assertEqual(path.read_bytes(),before)
 def test_A04_success_restart_faults(self):
  self.assertEqual(self.cb(1,'SUCCEEDED','before'),'503 retry'); self.state('PENDING|0|false')
  self.assertEqual(self.cb(1,'SUCCEEDED','after'),'503 response_lost'); self.state('SUCCEEDED|1|false')
  self.assertEqual(self.cb(1,'SUCCEEDED'),'200 duplicate'); self.state('SUCCEEDED|1|false')
 def test_A04_review_restart_faults(self):
  self.cb(1,'FAILED')
  self.assertEqual(self.cb(2,'SUCCEEDED','before'),'503 retry'); self.state('FAILED|0|false')
  self.assertEqual(self.cb(2,'SUCCEEDED','after'),'503 response_lost'); self.state('FAILED|0|true')
  self.assertEqual(self.cb(2,'SUCCEEDED'),'200 duplicate'); self.state('FAILED|0|true')
 def test_A05_cancellation_success_and_stale_receipts(self):
  self.cb(2,'CANCELLED'); self.cb(3,'SUCCEEDED'); self.state('SUCCEEDED|1|false')
  self.assertEqual(self.cb(1,'PROCESSING','before'),'503 retry')
  self.assertEqual(self.cb(1,'PROCESSING','after'),'503 response_lost')
  self.assertEqual(self.cb(1,'PROCESSING'),'200 duplicate')
  self.assertEqual(self.cb(1,'CANCELLED'),'409 event_conflict')
  self.state('SUCCEEDED|1|false')
 def test_concurrent_duplicates(self):
  sig=hmac.new(b'fixture-only-not-production',b'r1|1|SUCCEEDED',hashlib.sha256).hexdigest()
  args=['java','-cp',self.build.name,'bench.Main',self.tmp.name,'callback','r1','1','SUCCEEDED',sig,'none']
  ps=[subprocess.Popen(args,stdout=subprocess.PIPE,text=True) for _ in range(8)]
  outputs=[p.communicate()[0].strip() for p in ps]
  self.assertEqual(outputs.count('200 applied'),1)
  self.assertEqual(outputs.count('200 duplicate'),7)
  self.state('SUCCEEDED|1|false')

if __name__=='__main__': unittest.main(verbosity=2)
