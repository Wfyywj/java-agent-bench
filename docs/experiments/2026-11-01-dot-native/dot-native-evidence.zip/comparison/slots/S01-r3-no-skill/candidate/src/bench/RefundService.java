package bench;

import java.util.Set;

/** Applies authenticated events and their receipt in the same persisted snapshot. */
public final class RefundService {
 public String callback(Store db, String id, String seqText, String next,
                        String signature, String fault) throws Exception {
  if (!Signature.valid(id + "|" + seqText + "|" + next, signature))
   return "401 invalid_signature";
  if (!db.get(id + ".known", "false").equals("true")) return "404 unknown_refund";
  int seq;
  try {
   seq = Integer.parseInt(seqText);
   if (seq < 1) throw new NumberFormatException();
  } catch (NumberFormatException e) { return "422 invalid_sequence"; }
  if (!Set.of("PROCESSING", "SUCCEEDED", "FAILED", "CANCELLED").contains(next))
   return "422 invalid_state";

  String event = id + ".event." + seq;
  String prior = db.get(event, "");
  if (!prior.isEmpty()) return prior.equals(next) ? "200 duplicate" : "409 event_conflict";

  String old = db.get(id + ".status", "PENDING");
  boolean conflict = (old.equals("SUCCEEDED") && next.equals("FAILED"))
                   || (old.equals("FAILED") && next.equals("SUCCEEDED"));
  boolean stale = seq <= db.number(id + ".seq");
  boolean terminal = old.equals("SUCCEEDED") || old.equals("FAILED");
  String result;

  // Stage changes separately: a pre-commit failure must not leak even when the
  // caller reuses this Store instance instead of restarting the JVM.
  var snapshot = new java.util.Properties();
  snapshot.putAll(db.data);
  db.set(event, next); // Even ignored/stale events reserve their sequence/body.
  if (conflict) {
   db.set(id + ".review", true);
   result = "409 manual_review";
  } else if (stale || (terminal && !old.equals(next))) {
   result = "200 stale";
  } else {
   db.set(id + ".status", next);
   db.set(id + ".seq", seq);
   // Ledger is a projection of the first accepted success, not callback count.
   if (next.equals("SUCCEEDED") && !old.equals("SUCCEEDED"))
    db.set(id + ".ledger", db.number(id + ".ledger") + 1);
   result = "200 applied";
  }
  if (fault.equals("before")) {
   db.data.clear(); db.data.putAll(snapshot);
   return "503 retry";
  }
  try { db.commit(); }
  catch (Exception e) { db.data.clear(); db.data.putAll(snapshot); throw e; }
  return fault.equals("after") ? "503 response_lost" : result;
 }
}
