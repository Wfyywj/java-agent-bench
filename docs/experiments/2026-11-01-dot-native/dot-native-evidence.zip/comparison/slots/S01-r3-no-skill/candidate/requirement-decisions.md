# Requirement decisions

Authority: supplied PROMPT.md binding decisions take precedence over planning-only
infrastructure in original-task.json. No clarification or user answer is invented.

- Preserve Main's arguments, response vocabulary, signature payload and get format.
- Success cannot regress to processing or cancellation. Failure is likewise terminal
  against nonterminal updates. Repeated success at a new sequence does not add a
  second ledger entry.
- SUCCEEDED versus FAILED is a conflict regardless of sequence order. Retain the
  existing status and ledger, durably set review, and receipt the conflicting event.
- Cancellation represents a request. A higher-sequence success supersedes it.
  Assumption: non-conflicting events at or below the accepted sequence remain stale,
  including success older than a cancellation. Sequence is provider ordering, not
  arrival time. No real payment action is taken.
- Every valid known-refund event receives a durable sequence/body receipt, even if
  stale or terminal-protected. Replays return duplicate; changing the state for that
  sequence returns event_conflict without overwriting the original receipt.
- Invalid signature is rejected before other processing. Missing/invalid sequence
  is 422 for a known refund; unknown refunds are 404. Rejections do not commit.
- Before-commit injection rolls back staged in-memory changes; after-commit injection
  loses only the response. Both apply to normal, stale and review paths.
- No tenant identifier exists in the public CLI. Tenant authentication and identity
  binding remain outside this fixture; this does not claim production suitability.

No blocking clarification is needed for this local fixture. The sequence assumption
above must be confirmed before adopting the policy in a real payment integration.
