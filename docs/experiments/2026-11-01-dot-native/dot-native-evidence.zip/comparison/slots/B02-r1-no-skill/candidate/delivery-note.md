# Delivery note

## Changed files
- src/ReturnService.java: replay persisted results, reject changed payloads, and restrict first-use returns to matching BORROWED loans. No public API, model, HTTP parsing, snapshot format or repository changes.
- requirement-decisions.md and evidence-map.md: business answers, assumptions, evidence and scope.
- regression-tests/test_returns.py and README.md: five local HTTP regression groups mapped to B02-A01–A05.
- delivery-note.md: this report.

## Verification
Ran `python3 candidate/regression-tests/test_returns.py` from the slot directory: 5 tests passed in 13.685 seconds using Java 21 and Python 3.12.14. This compiles candidate sources with the JDK compiler entry point. The first attempt could not locate a standalone javac executable and ran zero tests; the suite was updated to invoke the installed compiler through java and rerun successfully.

The tests cover normal and damaged replay, process restarts, changed payload conflicts, tenant scope/non-disclosure, unavailable/retired/wrong equipment, three staged failure points, effect-free rejections, and simultaneous independent HTTP clients. Public fixture hashes and nonmodified Java source hashes were checked against PREPARED.json.

## Rollback
Stop the single writer before deployment or rollback and preserve a backup of its snapshot. Revert only ReturnService.java to the prior version and recompile to roll back code; format compatibility is unchanged, so no data migration is needed. The old code reintroduces duplicate-job and token-binding defects: do not enable traffic on the rolled-back version without accepting those risks. No existing duplicated data was deleted or repaired.

## Unverified / limits
No unavailable benchmark selfcheck or verifier was invoked. PostgreSQL transactions, database unique constraints, two database connections, fsync/power-loss/crash durability, multi-process locking, malformed/corrupt snapshots and historical duplicate reconciliation were not validated. A03 and A05 are local-adapter evidence, not full infrastructure acceptance. No crash recovery or automatic availability workflow was added.
