# Evidence map

All inputs are synthetic public development evidence. Tests are candidate-authored and do not use the unavailable evaluator.

| Acceptance | Public evidence / implementation | Regression evidence |
| --- | --- | --- |
| B02-A01 | incident.log; tenant/token event lookup and stored response in ReturnService; Store reloads E rows | test_B02_A01: replay equality, byte-identical snapshot, restart, one job/event, CLEANING persistence, second-token rejection |
| B02-A02 | PROMPT binding rule; schema.sql composite event key; full payload comparison | test_B02_A02: equipment, damage and loan conflicts without mutation; restart conflict; same token succeeds independently for tenantB |
| B02-A03 | PROMPT fault stages; existing copy-on-write Store and atomic move | test_B02_A03: all three stages for normal and damaged returns yield 503, identical persisted bytes, restart and successful retry, event/job/state checks |
| B02-A04 | seed unavailable/retired/cross-tenant loans; authorize first and BORROWED/equipment guard | test_B02_A04: indistinguishable missing/foreign 404; unavailable/retired/wrong-equipment 409; normal/damaged mismatch; unchanged snapshot across restarts; corrected same-token success and replay |
| B02-A05 | PROMPT single-writer architecture; schema uniqueness is planned only | test_B02_A05: barrier-started independent HTTP connections for both normal and damaged returns; one event, expected job count; REVIEW survives restart, replay and second-token rejection |

A03 establishes staged-failure atomicity in the local snapshot adapter only. A05 establishes concurrent HTTP behavior under the existing single-process service lock only. Neither establishes PostgreSQL transaction/uniqueness behavior, two database connections, fsync or multi-process locking.
