# Requirement decisions

## Provided business answers (not inferred)
The frozen contract in PROMPT.md controls the repair. Tenant-scoped tokens bind loan, equipment and damage; successful exact replay returns its stored response even after restart. Changed payload conflicts. Only the borrowed loan's equipment is returnable; wrong tenant and missing loan share 404. Normal returns enter CLEANING with one job; damaged returns enter REVIEW with none. Three injected staged-write failures must leave no effects. One process/writer serves concurrent HTTP clients. Public API and fixtures remain unchanged.

## Implementation decisions / assumptions
- Resolve and authorize the requested loan before token lookup/replay to preserve non-disclosure. Thus nonexistent or foreign loans return 404 even if a supplied token exists. A changed loan owned by the same tenant returns TOKEN_CONFLICT. This precedence resolves overlapping error conditions; the contract does not explicitly order them.
- For authorized loans, compare a prior event before current lifecycle/equipment validation. Otherwise legitimate replay would fail after the first return, and a changed token payload could incorrectly become NOT_RETURNABLE.
- Without a prior event, require BORROWED (not CLEANING or REVIEW) and the exact equipment. Another token cannot create a second return.
- Retain synchronized submit, copy-on-write Store and atomic snapshot replacement. All checks and publication remain under the single service writer lock. This is the supplied one-service adapter architecture, not multi-instance/multi-process safety.
- Treat existing snapshots as valid input. No repair of historical duplicate jobs, new inventory transitions, schema migration, or file-format change is authorized or needed for this narrow fix.
- Tests decode the public seed's literal backslash-t separators into tabs when making disposable snapshots. The public seed itself is preserved.

## Evidence reviewed before implementation
incident.log shows one event but two jobs after a retry. ReturnService looked up a prior event without using it, allowed CLEANING, then overwrote the event key while appending another job. Store persists event results and snapshots, so replay belongs in the service boundary before mutation, not in an ephemeral HTTP cache. schema.sql specifies tenant/token and loan uniqueness plus a single transaction; it is design evidence only. seed.tsv covers borrowed, available, retired and cross-tenant loans.
