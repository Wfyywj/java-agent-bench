"""Local HTTP/snapshot regressions; no benchmark or external dependencies."""
import concurrent.futures
import http.client
from pathlib import Path
import select
import subprocess
import tempfile
import threading
import unittest
import urllib.parse

ROOT = Path(__file__).resolve().parents[1]

class Returns(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.build = tempfile.TemporaryDirectory(dir=ROOT / 'regression-tests')
        subprocess.run(['java', 'com.sun.tools.javac.Main', '-d', cls.build.name, *map(str, (ROOT / 'src').glob('*.java'))], check=True)

    @classmethod
    def tearDownClass(cls):
        cls.build.cleanup()

    def setUp(self):
        self.work = tempfile.TemporaryDirectory(dir=ROOT / 'regression-tests')
        self.snapshot = Path(self.work.name) / 'store.tsv'
        # Public fixture uses printable backslash-t; the adapter expects actual tabs.
        self.snapshot.write_text((ROOT / 'evidence/seed.tsv').read_text().replace('\\t', '\t'))
        self.start()

    def start(self):
        self.proc = subprocess.Popen(['java', '-Xmx96m', '-cp', self.build.name, 'App', str(self.snapshot)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if not select.select([self.proc.stdout], [], [], 10)[0]:
            self.stop()
            self.fail('Server startup timeout')
        self.port = int(self.proc.stdout.readline())

    def stop(self):
        self.proc.terminate()
        try:
            self.proc.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            self.proc.kill()
            self.proc.communicate()

    def restart(self):
        self.stop()
        self.start()

    def tearDown(self):
        self.stop()
        self.work.cleanup()

    def post(self, fault=0, **changes):
        payload = dict(tenant='tenantA', loan='loan1', token='cabinet77', equipment='bat1', damaged='false')
        payload.update(changes)
        conn = http.client.HTTPConnection('127.0.0.1', self.port, timeout=5)
        try:
            conn.request('POST', '/returns', urllib.parse.urlencode(payload), {'Content-Type': 'application/x-www-form-urlencoded', 'X-Test-Fault': str(fault)})
            reply = conn.getresponse()
            return reply.status, reply.read().decode()
        finally:
            conn.close()

    def rows(self, kind):
        return [line.split('\t') for line in self.snapshot.read_text().splitlines() if line.startswith(kind + '\t')]

    def assertEffects(self, loan, state, jobs, events):
        row = next(r for r in self.rows('L') if r[1] == loan)
        self.assertEqual(row[4], state)
        self.assertEqual(sum(r[1] == loan for r in self.rows('C')), jobs)
        self.assertEqual(sum(r[2] == loan for r in self.rows('E')), events)

    def test_B02_A01_replay_restart_and_second_token(self):
        expected = (200, 'loan=loan1;state=CLEANING')
        self.assertEqual(self.post(), expected)
        snapshot = self.snapshot.read_bytes()
        self.assertEqual(self.post(), expected)
        self.assertEqual(self.snapshot.read_bytes(), snapshot)
        self.restart()
        self.assertEqual(self.post(), expected)
        self.assertEqual(self.post(token='another'), (409, 'NOT_RETURNABLE'))
        self.assertEqual(self.snapshot.read_bytes(), snapshot)
        self.assertEffects('loan1', 'CLEANING', 1, 1)

    def test_B02_A02_bound_payload_and_tenant_scope(self):
        self.assertEqual(self.post()[0], 200)
        snapshot = self.snapshot.read_bytes()
        for change in [dict(equipment='ball2'), dict(damaged='true'), dict(loan='loan2', equipment='ball2')]:
            with self.subTest(change=change):
                self.assertEqual(self.post(**change), (409, 'TOKEN_CONFLICT'))
                self.assertEqual(self.snapshot.read_bytes(), snapshot)
        self.restart()
        self.assertEqual(self.post(damaged='true'), (409, 'TOKEN_CONFLICT'))
        self.assertEqual(self.post(tenant='tenantB', loan='loan3', equipment='mat3'), (200, 'loan=loan3;state=CLEANING'))
        self.assertEffects('loan3', 'CLEANING', 1, 1)

    def test_B02_A03_all_staged_failures_retry(self):
        for damaged in ['false', 'true']:
            for stage in [1, 2, 3]:
                with self.subTest(damaged=damaged, stage=stage):
                    self.stop()
                    self.snapshot.write_text((ROOT / 'evidence/seed.tsv').read_text().replace('\\t', '\t'))
                    self.start()
                    before = self.snapshot.read_bytes()
                    self.assertEqual(self.post(fault=stage, damaged=damaged), (503, 'RETRY_LATER'))
                    self.assertEqual(self.snapshot.read_bytes(), before)
                    self.restart()
                    self.assertEqual(self.snapshot.read_bytes(), before)
                    state = 'REVIEW' if damaged == 'true' else 'CLEANING'
                    expected = (200, 'loan=loan1;state=' + state)
                    self.assertEqual(self.post(damaged=damaged), expected)
                    self.assertEqual(self.post(damaged=damaged), expected)
                    self.assertEffects('loan1', state, int(damaged == 'false'), 1)

    def test_B02_A04_validation_is_effect_free(self):
        before = self.snapshot.read_bytes()
        for change, expected in [
            (dict(tenant='tenantB'), (404, 'NOT_FOUND')),
            (dict(loan='missing'), (404, 'NOT_FOUND')),
            (dict(loan='loan4', equipment='cone4'), (409, 'NOT_RETURNABLE')),
            (dict(loan='loan5', equipment='net5'), (409, 'NOT_RETURNABLE')),
            (dict(equipment='ball2'), (409, 'NOT_RETURNABLE')),
            (dict(equipment='ball2', damaged='true'), (409, 'NOT_RETURNABLE')),
        ]:
            with self.subTest(change=change):
                self.assertEqual(self.post(**change), expected)
                self.assertEqual(self.snapshot.read_bytes(), before)
                self.restart()
                self.assertEqual(self.snapshot.read_bytes(), before)
        self.assertEqual(self.post(), (200, 'loan=loan1;state=CLEANING'))
        self.restart()
        self.assertEqual(self.post(), (200, 'loan=loan1;state=CLEANING'))
        self.assertEffects('loan1', 'CLEANING', 1, 1)

    def test_B02_A05_concurrent_normal_and_damaged(self):
        for loan, equipment, damaged, state in [('loan1', 'bat1', 'false', 'CLEANING'), ('loan2', 'ball2', 'true', 'REVIEW')]:
            barrier = threading.Barrier(2)
            def send():
                barrier.wait(timeout=5)
                return self.post(loan=loan, equipment=equipment, token=loan, damaged=damaged)
            with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
                futures = [pool.submit(send) for _ in range(2)]
                self.assertEqual([f.result(timeout=10) for f in futures], [(200, f'loan={loan};state={state}')] * 2)
            self.assertEffects(loan, state, int(damaged == 'false'), 1)
            self.restart()
            self.assertEqual(self.post(loan=loan, equipment=equipment, token=loan, damaged=damaged), (200, f'loan={loan};state={state}'))
            self.assertEqual(self.post(loan=loan, equipment=equipment, token='new-' + loan, damaged=damaged), (409, 'NOT_RETURNABLE'))
            self.assertEffects(loan, state, int(damaged == 'false'), 1)

if __name__ == '__main__':
    unittest.main(verbosity=2)
