# Local regression suite

From this candidate directory run:

    python3 regression-tests/test_returns.py

Python standard library only; requires the installed Java 21 runtime with jdk.compiler. Compilation uses `java com.sun.tools.javac.Main` because this environment has no `javac` executable on PATH. The suite compiles all candidate sources and starts real loopback HTTP processes, each with disposable snapshots beneath regression-tests/. It cleans temporary build/snapshot directories. No reference, verifier, selfcheck, database or network service is required.

The five named test methods correspond directly to B02-A01 through A05; see ../evidence-map.md for assertions and scope. Requests use independent HTTP connections. Tests inspect full snapshot bytes for rejected requests and staged failures, and count persisted events/jobs as well as checking HTTP responses.
