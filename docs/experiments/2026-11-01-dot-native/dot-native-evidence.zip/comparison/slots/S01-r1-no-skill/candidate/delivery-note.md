# Delivery

## Changed files
- `src/bench/RefundService.java`: explicit transition guards, once-only success projection, durable ignored receipts, uniform fault boundaries including manual review.
- `regression-tests/test_refunds.py`: standalone synthetic restart, validation, cancellation, concurrency and fault regressions.
- Requirement decisions and evidence map document assumptions and acceptance-ID coverage.

Unchanged: Main, Store, Signature and all public input materials. CLI arguments and result/get formatting remain unchanged. First-seen ignored events now commit receipts; their replays return duplicate rather than repeatedly stale. An injected after fault on a review event now returns response_lost, consistently with other committed first-seen events.

## Reproduction and actual execution
Run from candidate: `python3 regression-tests/test_refunds.py` with Java 21 `java` on PATH and the `jdk.compiler` module installed (or `javac` on PATH).
Initial attempt could not run compilation because `javac` is absent from PATH; JAVA_HOME was empty. The installed Java runtime does include `jdk.compiler`, so the script now falls back to `java com.sun.tools.javac.Main`. With that compiler, compilation and all 54 synthetic assertions passed on Java 21.0.12.1. Every CLI invocation launched a new JVM, including 12 concurrent duplicate submissions. Python syntax compilation also passed. No benchmark selfcheck was attempted.

## Scope, risks and recovery
File replacement provides atomic visibility under the existing JVM-independent file lock, not fsync/power-loss durability. No distributed delivery, HTTP adapter, database engine, production secrets or payment dispatch is added. Test fixtures use only the supplied synthetic secret. Existing historical corrupt projections are not automatically repaired; receipt data cannot reconstruct financial truth safely.

Rollback: stop writers, preserve the complete state directory and lock discipline, restore the prior code only after evaluating its known regression/duplicate-billing risk. Do not delete receipts, reset the ledger or replay actual payments. New receipt records use the existing property schema; take a filesystem snapshot before any operational experiment. Unverified: independent acceptance tests, unusual filesystems, abrupt OS/power failure, production-scale performance and tenant binding. Sequence/cancellation interpretation is explicit in requirement-decisions.md.
