# Requirement decisions

## Binding contract
- The supplied executable prompt takes precedence over the older design-only infrastructure plan. Preserve the existing CLI, fixture-only HMAC, property file layout, known refunds, and output format.
- A01: success is terminal against processing/cancellation, regardless of sequence. Failure is likewise protected from nonterminal regressions. Cancellation cannot override success; a newer success may supersede cancellation.
- A02: SUCCEEDED versus FAILED queues durable manual review without selecting a new monetary outcome, even if the conflicting event has an older sequence. Review is sticky. Successful billing is applied once per refund, not once per success event.
- A03: signatures are checked before business writes. No signatures or keys are logged.
- A04: all valid first-seen event receipts (including stale/ignored/conflicting events), projection, ledger and review flags commit in one atomic file replacement. The before fault changes nothing; the after fault loses only the response. Replays identify the committed receipt.
- A05: missing, nonnumeric, nonpositive or overflowing integer sequence is 422; a signed unknown refund is 404. Same refund/sequence and different state is 409 event_conflict.

## Explicit assumptions and interpretation
Sequence denotes provider ordering, not arrival time. Nonconflicting events at or below the last applied sequence are ignored but receipted. In particular a success with an older sequence than cancellation is stale; the prompt's *later success* is interpreted as a newer sequence. Opposing terminal monetary evidence is the safety exception and requires review even when stale. Processing cannot undo cancellation. CANCELLED may advance to FAILED or SUCCEEDED. Same terminal outcome at a newer sequence is ignored and receipted, not billed again. The event body in this CLI is the refund identity, integer sequence and state; alternative textual representations of the same integer identify the same event. Ignored events do not advance the projection sequence.

These interpretations do not authorize any payment action. No real payment integration is present or added. No user clarification or hidden acceptance result is claimed. Tenant identity is absent from this fixed CLI, so multi-tenant authentication cannot be implemented without changing the contract.
