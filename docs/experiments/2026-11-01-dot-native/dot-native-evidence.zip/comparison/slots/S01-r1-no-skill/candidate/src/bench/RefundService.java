package bench;

import java.util.Set;

public final class RefundService {
 public String callback(Store db, String id, String seqText, String next,
                        String signature, String fault) throws Exception {
  if (!Signature.valid(id + "|" + seqText + "|" + next, signature))
   return "401 invalid_signature";
  if (!db.get(id + ".known", "false").equals("true")) return "404 unknown_refund";
  int seq;
  try {
   seq = Integer.parseInt(seqText);
   if (seq < 1) throw new NumberFormatException();
  } catch (NumberFormatException e) { return "422 invalid_sequence"; }
  if (!Set.of("PROCESSING", "SUCCEEDED", "FAILED", "CANCELLED").contains(next))
   return "422 invalid_state";

  String event = id + ".event." + seq;
  String prior = db.get(event, "");
  if (!prior.isEmpty()) return prior.equals(next) ? "200 duplicate" : "409 event_conflict";

  String old = db.get(id + ".status", "PENDING");
  boolean conflict = (old.equals("SUCCEEDED") && next.equals("FAILED"))
                  || (old.equals("FAILED") && next.equals("SUCCEEDED"));
  // Conflicting money outcomes require review even when delivered out of order.
  // Cancellation only requests cancellation; it cannot invalidate a later success.
  boolean stale = seq <= db.number(id + ".seq");
  boolean protectedState = old.equals("SUCCEEDED") || old.equals("FAILED")
                        || (old.equals("CANCELLED") && next.equals("PROCESSING"));
  boolean apply = !conflict && !stale && !protectedState;
  String result = conflict ? "409 manual_review" : apply ? "200 applied" : "200 stale";

  // All accepted receipts, including ignored events, share the same atomic commit
  // as their projection. A retry must not reinterpret an already received body.
  if (fault.equals("before")) return "503 retry";
  db.set(event, next);
  if (conflict) db.set(id + ".review", true);
  if (apply) {
   db.set(id + ".status", next);
   db.set(id + ".seq", seq);
   if (next.equals("SUCCEEDED")) db.set(id + ".ledger", db.number(id + ".ledger") + 1);
  }
  db.commit();
  return fault.equals("after") ? "503 response_lost" : result;
 }
}
