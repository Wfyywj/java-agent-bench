#!/usr/bin/env python3
"""Synthetic CLI regressions: each invocation starts a separate JVM."""
import hashlib, hmac, pathlib, subprocess, tempfile, concurrent.futures, shutil
ROOT = pathlib.Path(__file__).resolve().parents[1]
KEY = b'fixture-only-not-production'
count = 0
with tempfile.TemporaryDirectory(dir=ROOT / 'regression-tests') as tmp:
    tmp = pathlib.Path(tmp)
    classes = tmp / 'classes'
    classes.mkdir()
    compiler = ['javac'] if shutil.which('javac') else ['java', 'com.sun.tools.javac.Main']
    subprocess.run([*compiler, '-d', str(classes), *map(str, (ROOT / 'src').rglob('*.java'))], check=True)
    def run(db, *args):
        return subprocess.check_output(['java', '-cp', str(classes), 'bench.Main', str(db), *args], text=True).strip()
    def fresh(name):
        db = tmp / name
        assert run(db, 'init') == '200 initialized'
        return db
    def call(db, seq, state, fault='none', rid='r1', signature=None):
        payload = f'{rid}|{seq}|{state}'.encode()
        sig = hmac.new(KEY, payload, hashlib.sha256).hexdigest() if signature is None else signature
        return run(db, 'callback', rid, str(seq), state, sig, fault)
    def eq(actual, expected):
        global count
        assert actual == expected, (actual, expected)
        count += 1
    def get(db, expected): eq(run(db, 'get', 'r1'), expected)
    # A01/A02: success stays terminal, including new sequences and repeats.
    db = fresh('terminal')
    eq(call(db, 3, 'SUCCEEDED'), '200 applied')
    for seq, state in [(1,'PROCESSING'), (4,'PROCESSING'), (5,'CANCELLED'), (6,'SUCCEEDED')]:
        eq(call(db, seq, state), '200 stale')
        get(db, 'SUCCEEDED|1|false')
        eq(call(db, seq, state), '200 duplicate')
    eq(call(db, 1, 'CANCELLED'), '409 event_conflict')
    eq(call(db, 2, 'FAILED'), '409 manual_review')
    get(db, 'SUCCEEDED|1|true')
    # A02/A04: review is durable and participates in both fault boundaries.
    for old, new in [('FAILED','SUCCEEDED'), ('SUCCEEDED','FAILED')]:
        db = fresh('conflict' + old)
        call(db, 5, old)
        snapshot = (db / 'state.properties').read_bytes()
        eq(call(db, 1, new, 'before'), '503 retry')
        eq((db / 'state.properties').read_bytes(), snapshot)
        eq(call(db, 1, new, 'after'), '503 response_lost')
        eq(call(db, 1, new), '200 duplicate')
        get(db, f'{old}|{int(old == "SUCCEEDED")}|true')
    # A04: no receipt or billing survives precommit; postcommit is deduplicated.
    db = fresh('fault')
    snapshot = (db / 'state.properties').read_bytes()
    eq(call(db, 1, 'SUCCEEDED', 'before'), '503 retry')
    eq((db / 'state.properties').read_bytes(), snapshot)
    get(db, 'PENDING|0|false')
    eq(call(db, 1, 'SUCCEEDED', 'after'), '503 response_lost')
    eq(call(db, 1, 'SUCCEEDED'), '200 duplicate')
    get(db, 'SUCCEEDED|1|false')
    # A03/A05: rejected input cannot write business state.
    db = fresh('validation')
    snapshot = (db / 'state.properties').read_bytes()
    for seq in ['', '0', '-1', 'bad', '2147483648']:
        eq(call(db, seq, 'SUCCEEDED'), '422 invalid_sequence')
    eq(call(db, 1, 'UNKNOWN'), '422 invalid_state')
    eq(call(db, 1, 'SUCCEEDED', rid='unknown'), '404 unknown_refund')
    eq(call(db, 1, 'SUCCEEDED', signature='broken'), '401 invalid_signature')
    eq((db / 'state.properties').read_bytes(), snapshot)
    # A05: cancellation cannot prevent a subsequent successful refund.
    db = fresh('cancel')
    eq(call(db, 1, 'CANCELLED'), '200 applied')
    eq(call(db, 2, 'PROCESSING'), '200 stale')
    eq(call(db, 3, 'SUCCEEDED'), '200 applied')
    get(db, 'SUCCEEDED|1|false')
    # A01/A02: stale receipt retained even before success; per-refund isolation.
    db = fresh('stale')
    call(db, 5, 'PROCESSING')
    eq(call(db, 2, 'CANCELLED', 'after'), '503 response_lost')
    eq(call(db, 2, 'CANCELLED'), '200 duplicate')
    eq(call(db, 2, 'SUCCEEDED'), '409 event_conflict')
    get(db, 'PROCESSING|0|false')
    call(db, 1, 'SUCCEEDED', rid='r2')
    get(db, 'PROCESSING|0|false')
    eq(run(db, 'get', 'r2'), 'SUCCEEDED|1|false')
    # A02/A04: independent JVMs serialize under the store lock.
    db = fresh('parallel')
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        results = list(pool.map(lambda _: call(db, 1, 'SUCCEEDED'), range(12)))
    eq(results.count('200 applied'), 1)
    eq(results.count('200 duplicate'), 11)
    get(db, 'SUCCEEDED|1|false')
print(f'PASS: {count} assertions; each CLI command used a fresh JVM')
