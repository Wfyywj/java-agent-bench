# Evidence map

| Requirement | Source evidence and implementation | Local regression evidence |
|---|---|---|
| A01 state monotonicity | `RefundService.callback`: conflict, stale and protectedState gates separate receipt from projection | terminal, stale, cancel scenarios |
| A02 exactly-once billing, manual review | `RefundService.callback`: receipt check precedes transitions; only entry into success increments ledger; conflicting outcomes never overwrite status | terminal, conflict in both directions, parallel duplicate JVMs, per-refund isolation |
| A03 validation | Existing `Signature.valid` verifies HMAC; validation returns before writes; Main prints result/status only | validation byte-compares state after signed malformed input and invalid signature |
| A04 restart durability | Existing `Store` locks directory, writes a complete temporary snapshot then atomic-renames; callback sends all first-seen branches through a common fault/commit path | precommit byte equality, postcommit duplicate/review, new JVM every command |
| A05 cancellation and rejection contracts | newer success can advance CANCELLED; success cannot advance to CANCELLED; existing validation order retained | cancel, terminal, missing sequence, unknown refund |

Diagnosis: the baseline allowed any newer callback to replace success and billed each new success, so receipt deduplication alone could not solve monetary duplication. It also omitted stale receipts and bypassed after-commit fault simulation for review; simple status protection would leave both issues. Existing store locking and atomic replacement already provide the bounded filesystem transaction; replacing it with a database is unnecessary and outside scope.

Evidence is restricted to supplied sources and local synthetic tests. No external benchmark/oracle or production evidence was used. Execution status is recorded in delivery-note.md.
