# Evidence map

| Acceptance | Implementation evidence | Executed regression evidence |
|---|---|---|
| A01 stable projection | RefundService terminal guard and sequence comparison | Older/newer processing after success; cancellation after success; failure stability |
| A02 once-only billing and review | Ledger increment only in nonterminal transition to success; symmetric conflict guard; receipt comparison precedes transition | Distinct/replayed successes, both conflict directions, same-sequence state collision, independent refunds, concurrent JVM writers |
| A03 signature boundary | Existing Signature.valid and callback's first early return | Invalid hex/empty/short signatures; entire persisted snapshot unchanged; no signature or secret logged |
| A04 durable fault behavior | Shared receipt/commit return path; unchanged Store atomic file replacement under file lock | Before and after faults on success, review and stale paths, each followed by new-JVM retry; conflicting retry checks receipt persistence |
| A05 cancellation and validation | Explicit cancellation-success exception; existing validation | Lower/higher sequence success after cancellation, unknown refund and missing/bad sequences |

Rejected explanation: merely rejecting lower sequences is insufficient because higher-sequence processing could overwrite a terminal state. Receipt deduplication alone is insufficient because distinct success event IDs can double count. Ignoring stale callbacks without receipts misses later same-sequence conflicts. Store already provides the local transaction boundary, so no new database dependency is needed.

Evidence scope: synthetic CLI tests only, not evaluator acceptance or production integration. No genuine payment request exists in this implementation.
