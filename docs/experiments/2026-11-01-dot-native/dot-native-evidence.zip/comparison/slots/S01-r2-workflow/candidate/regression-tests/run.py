#!/usr/bin/env python3
"""Synthetic CLI regression tests; every invocation starts a fresh JVM."""
import concurrent.futures
import hashlib
import hmac
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
KEY = b'fixture-only-not-production'
checks = 0

def eq(actual, expected):
    global checks
    assert actual == expected, (actual, expected)
    checks += 1

with tempfile.TemporaryDirectory(dir=ROOT / 'regression-tests') as tmp:
    tmp = Path(tmp)
    classes = tmp / 'classes'
    classes.mkdir()
    subprocess.run(['java', '-XX:-UsePerfData', '-m', 'jdk.compiler/com.sun.tools.javac.Main', '-d', str(classes), *map(str, (ROOT / 'src').rglob('*.java'))], check=True)
    count = 0
    def cli(db, *args):
        return subprocess.check_output(['java', '-XX:-UsePerfData', '-cp', str(classes), 'bench.Main', str(db), *args], text=True).strip()
    def fresh():
        global count
        count += 1
        db = tmp / str(count)
        eq(cli(db, 'init'), '200 initialized')
        return db
    def cb(db, seq, state, fault='none', id='r1', sig=None):
        seq = str(seq)
        if sig is None:
            sig = hmac.new(KEY, f'{id}|{seq}|{state}'.encode(), hashlib.sha256).hexdigest()
        return cli(db, 'callback', id, seq, state, sig, fault)
    def get(db, id='r1'):
        return cli(db, 'get', id)

    # S01-A01/A02: success is stable; repeated successes do not rebill.
    db = fresh()
    eq(cb(db, 2, 'SUCCEEDED'), '200 applied')
    for seq, state in [(1,'PROCESSING'), (3,'PROCESSING'), (4,'CANCELLED'), (5,'SUCCEEDED')]:
        eq(cb(db, seq, state), '200 stale')
        eq(get(db), 'SUCCEEDED|1|false')
        eq(cb(db, seq, state), '200 duplicate')
    eq(cb(db, 3, 'FAILED'), '409 event_conflict')
    eq(cb(db, 6, 'FAILED'), '409 manual_review')
    eq(get(db), 'SUCCEEDED|1|true')
    eq(get(db,'r2'), 'PENDING|0|false')

    # A02: both terminal-conflict directions, even out of sequence.
    db = fresh()
    eq(cb(db, 5, 'FAILED'), '200 applied')
    eq(cb(db, 2, 'SUCCEEDED'), '409 manual_review')
    eq(get(db), 'FAILED|0|true')
    eq(cb(db, 6, 'PROCESSING'), '200 stale')
    eq(get(db), 'FAILED|0|true')

    # A05: cancellation is a request, not proof that no money moved.
    for success_seq in [1, 3]:
        db = fresh()
        eq(cb(db, 2, 'CANCELLED'), '200 applied')
        eq(cb(db, success_seq, 'SUCCEEDED'), '200 applied')
        eq(get(db), 'SUCCEEDED|1|false')

    # Review-added coverage: ordinary ordering and cancellation protection.
    db = fresh()
    eq(cb(db, 4, 'PROCESSING'), '200 applied')
    eq(cb(db, 2, 'CANCELLED'), '200 stale')
    eq(cb(db, 2, 'SUCCEEDED'), '409 event_conflict')
    eq(get(db), 'PROCESSING|0|false')
    eq(cb(db, 5, 'CANCELLED'), '200 applied')
    eq(cb(db, 6, 'PROCESSING'), '200 stale')
    eq(get(db), 'CANCELLED|0|false')
    eq(cb(db, 7, 'SUCCEEDED'), '200 applied')
    eq(get(db), 'SUCCEEDED|1|false')

    # A03/A05: reject before writes, including malformed signatures.
    db = fresh()
    before = (db / 'state.properties').read_bytes()
    for seq in ['', '0', '-1', 'x', '2147483648']:
        eq(cb(db, seq, 'SUCCEEDED'), '422 invalid_sequence')
    eq(cb(db, 1, 'SUCCEEDED', id='missing'), '404 unknown_refund')
    eq(cb(db, 1, 'BOGUS'), '422 invalid_state')
    for sig in ['zz', '', '00']:
        eq(cb(db, 1, 'SUCCEEDED', sig=sig), '401 invalid_signature')
    eq((db / 'state.properties').read_bytes(), before)

    # A04: projection, review and stale receipt paths all have fault parity.
    for mode in ['success', 'review', 'stale']:
        for fault in ['before', 'after']:
            db = fresh()
            if mode == 'review': cb(db, 3, 'FAILED')
            if mode == 'stale': cb(db, 3, 'PROCESSING')
            snapshot = (db / 'state.properties').read_bytes()
            state = 'PROCESSING' if mode == 'stale' else 'SUCCEEDED'
            eq(cb(db, 1, state, fault), '503 retry' if fault == 'before' else '503 response_lost')
            if fault == 'before':
                eq((db / 'state.properties').read_bytes(), snapshot)
                eq(cb(db, 1, state), {'success':'200 applied','review':'409 manual_review','stale':'200 stale'}[mode])
            else:
                eq(cb(db, 1, state), '200 duplicate')
            eq(cb(db, 1, 'CANCELLED'), '409 event_conflict')
            eq(get(db), {'success':'SUCCEEDED|1|false','review':'FAILED|0|true','stale':'PROCESSING|0|false'}[mode])

    # A02/A04: serialized independent JVM writers, unique and duplicate seqs.
    db = fresh()
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        results = list(pool.map(lambda n: cb(db, n, 'SUCCEEDED'), [1,1,2,2,3,3]))
    eq(sum(x == '200 applied' for x in results), 1)
    eq(sum(x == '200 duplicate' for x in results), 3)
    eq(get(db), 'SUCCEEDED|1|false')
    print(f'PASS {checks} assertions; fresh-JVM persistence, faults and concurrency')
