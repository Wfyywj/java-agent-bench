# Workflow trace

## 1. clarify-task
Inspected PROMPT.md, original-task.json, PREPARED.json and all four Java sources. The prepared src/ is the editable baseline (there is no baseline/ directory). Existing CLI authenticates synthetic callbacks, locks the state file, and atomically replaces it at commit. Defects observed: higher-sequence PROCESSING/CANCELLED can overwrite success; repeated success at new sequence increments billing; stale events have no persisted receipts; manual-review branch ignores after-commit injection.
Goal: preserve CLI and durable per-refund event receipts while making terminal states stable, cancellation subordinate to success, and billing exactly once. Acceptance: signed valid callbacks only; 422 invalid sequence, 404 unknown refund; duplicate/conflicting receipts; monotonic projection; terminal conflict review; restart retry before/after commit. No network, payment requests, database engine, fsync guarantees, or new tenant contract. Binding decisions are sufficient; no blocking clarification needed.

## 2. plain-plan
Keep the file lock and atomic snapshot commit. For every authenticated valid new event, decide its projection effect and record its receipt in the same commit. Check receipt collisions first, then terminal conflicts, then terminal protections and cancellation priority, then normal sequence ordering. Bill only on first transition to success. All commit paths share fault handling. Verify in new JVMs using synthetic signatures and temporary stores; include stale receipt collisions, cancellation, conflict, fault replay, and concurrent callbacks.

## 3. implement-slice
Changed only RefundService.java in runtime code. Validation and receipt-collision precedence remain intact. Introduced terminal protection, cancellation-to-success priority, and one shared receipt/commit/fault path. Store/Main/Signature are unchanged. Added regression-tests/run.py using only stdlib and installed javac/java. No Git metadata consulted outside candidate; supplied hashes are the baseline evidence. No package dependencies added.

## 4. verify-change
First run could not locate a javac executable. Inspection of `java --list-modules` showed jdk.compiler, so the test now invokes its main class with `java -m jdk.compiler/com.sun.tools.javac.Main`. Next run exposed a JVM perfdata warning on stdout, unrelated to callback output; disabled JVM perfdata for isolated test subprocesses rather than loosening output assertions. Runtime: OpenJDK 21.0.12.1. Full suite command: `python3 candidate/regression-tests/run.py`. Benchmark selfcheck is unavailable and was not invoked.
First full suite result: PASS 81 assertions, exit 0; fresh JVM persistence, faults and concurrency.

## 5. review-change
Reviewed RefundService branches against Main's single-command lifetime and Store's lock/atomic rename behavior. Validation still precedes writes; collisions precede state processing; terminal conflicts preserve projection; receipt writes cover stale outcomes; after faults now apply to review too. No additional runtime defect confirmed. Found a coverage gap: cancellation-to-processing guard and ordinary nonterminal stale ordering were not directly exercised. Returned to implementation to add ten assertions covering these paths and stale-body conflicts, then reran the complete suite. No runtime code changes resulted from review. Missing coverage is not represented as an already-verified fact.
Review rerun: PASS 91 assertions, exit 0. SHA-256 comparison against supplied PREPARED.json confirms only RefundService.java differs among baseline runtime files and public inputs.

## 6. deliver-change
Local package is candidate/ with src/ and all required decision, evidence, test and delivery documents. Final test evidence is 91 assertions on the final code; no external CI was configured or queried and benchmark checks remain unverified. Delivery note records exact replay command, initial test-environment failures and fixes, risks and rollback guidance. No commit, publication, memory retention or external action performed.
