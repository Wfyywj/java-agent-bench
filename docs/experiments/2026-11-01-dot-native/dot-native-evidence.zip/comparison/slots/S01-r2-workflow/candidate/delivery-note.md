# Local delivery

Changed runtime file: src/bench/RefundService.java. Added requirement-decisions.md, evidence-map.md, regression-tests/run.py and workflow-trace.md. Main, Signature, Store and supplied public inputs are unchanged (verified against PREPARED.json SHA-256 values).

Implemented stable terminal projection, one ledger entry per successful refund, durable ignored-event receipts, cancellation-to-success priority, and uniform before/after commit fault handling including manual review.

Reproduce from the slot: `python3 candidate/regression-tests/run.py` (or from candidate: `python3 regression-tests/run.py`). Latest run: **PASS 91 assertions**, exit 0, OpenJDK 21.0.12.1. Compiles via installed jdk.compiler module because this environment has no javac executable. Tests disable JVM perfdata to avoid unrelated shared-host warning text, but assert full CLI output without filtering. No dependencies installed. All test state is temporary inside regression-tests and removed after running.

Unverified: hidden/evaluator tests, production integration, power-loss durability, filesystem support beyond this local atomic-move test, actual process-kill crash timing and distributed concurrency. CLI fault injection and independent-JVM concurrent writers were tested. No external CI, publication, real funds or secret access performed.

Recovery: stop writers and back up state.properties before deploying this local source change elsewhere. Recompile the original RefundService source to revert behavior; do not clear event receipts or replay payment requests. A source rollback restores the old unsafe transition behavior and is not recommended as a data repair. Existing corrupted billing values are not automatically reconciled; this patch prevents future duplication, not historical repair.
