# Workflow trace

## 1. clarify-task
Read PROMPT.md, original-task.json and all four source classes. The executable snapshot is already at src/ (not baseline/src/). CLI processes persist properties under an exclusive file lock and atomic rename; no database or HTTP layer exists. Observed defects: success can regress, fresh success sequences increment ledger again, stale events are not receipted, and manual-review after-commit faults are ignored.
Goal: authenticated per-refund monotonic terminal outcomes, durable event receipts and exactly-once billing, including restart retries. Binding cancellation policy and error codes are supplied; no clarification is blocking. Out of scope: real payments, tenant/API redesign, power-loss durability, production secrets.
Acceptance: A01 terminal stability and stale ordering; A02 duplicate/conflicting receipts, terminal review and single ledger entry; A03 invalid signature leaves bytes unchanged; A04 before/after faults across JVM restarts; A05 cancellation precedence, unknown IDs and invalid sequences.

## 2. plain-plan
Keep Main, Signature and Store contracts. Change RefundService only: validate before mutation, look up receipt, classify terminal conflicts before sequence ordering, prevent terminal regressions, and persist every accepted new receipt together with any projection update. A successful projection sets ledger to one, not an event counter. Existing atomic Store commit is reused; one common fault boundary covers applied, ignored and review receipts. Tests launch a new JVM for each command with synthetic signatures and inspect durable get results and file bytes.

## 3. implement-slice
Scope chosen: callback classification, receipts and billing in RefundService, plus local regression runner and delivery documentation. No external dependencies or dispatch are added. Existing source snapshot has no supplied build/test suite; use installed javac/java and Python. Public input files remain unchanged.

## 4. verify-change
Initial command `python3 candidate/regression-tests/run.py` failed before tests: javac executable is absent from PATH. `java --list-modules` confirmed jdk.compiler, and `java com.sun.tools.javac.Main -version` reported 21.0.12.1. Updated only the runner to use that installed compiler (no installation). Re-ran runner: exit 0, PASS 73 assertions with new JVMs for every command, byte-for-byte rejection/rollback checks, parallel processes, and refund isolation. This verifies the local synthetic CLI only; unavailable benchmark selfchecks were not invoked.

## 5. review-change
Compared supplied baseline behavior (recorded in clarification) against current RefundService and read its direct callers Main and Store. Signature validation remains first; all new receipts and projections use the same locked atomic commit; no payment/network path was introduced. Review found a coverage gap: ignored-event before-commit rollback was not explicitly tested, and compatibility with state-only historical receipts was asserted only by inspection. Returned these two cases to implementation as test additions (no production code change). Review also notes that baseline-created overcounted ledgers are not repaired by replay, and preexisting receipts lack exact lexical signed-body history; neither is silently presented as a migration capability.
Reverification after review additions: `python3 candidate/regression-tests/run.py` exited 0, PASS 81 assertions. The two review-driven test additions passed; production callback code remains the verified version.

## 6. deliver-change
Local-only delivery: src/bench/RefundService.java, requirement-decisions.md, evidence-map.md, regression-tests/run.py, delivery-note.md and this trace. Final runner output is PASS 81 assertions. Supplied public documents and other three source classes were not edited. No CI configuration or remote actions belong to this authorized local slice; CI and the unavailable benchmark selfcheck remain unverified. Delivery note records behavior changes, legacy-data limits, recovery cautions and exact rerun command. No learning or persistent memory was retained.
