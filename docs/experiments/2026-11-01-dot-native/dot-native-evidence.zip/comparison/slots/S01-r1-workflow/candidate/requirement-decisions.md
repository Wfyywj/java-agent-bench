# Requirement decisions
The executable PROMPT overrides the broader design-only original-task infrastructure list. Sources are in src/.
- Success remains terminal against processing and cancellation, regardless of sequence.
- Success and failure conflict in either order and set a durable manual-review flag without replacing the established result.
- Cancellation is a request: success supersedes it even when delivered out of order. Failure is also terminal against processing/cancellation.
- Otherwise the greatest accepted sequence governs ordinary progression. Ignored events still receive durable receipts; their replay is duplicate, and different signed bodies at the same numeric sequence conflict.
- Missing/nonpositive/noninteger sequence: 422; unknown refund: 404; authentication runs first and never mutates on failure.
- Billing counts successful refunds, not success notifications. Each refund can contribute at most one.
- Receipts, status, watermark, billing and review flag share the existing atomic local-file commit. Before-fault does not commit; after-fault commits but loses response. Existing duplicate response contract is retained on restart replay, including review receipts.
No user answers were invented; no blocking clarification remains. No tenant field exists in this CLI, so tenant isolation is not claimed or added.
