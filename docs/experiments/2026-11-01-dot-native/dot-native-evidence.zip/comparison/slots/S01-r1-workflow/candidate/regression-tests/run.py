#!/usr/bin/env python3
"""Synthetic CLI regression; each invocation is a fresh JVM, no network."""
import hashlib, hmac, pathlib, subprocess, tempfile, concurrent.futures
ROOT = pathlib.Path(__file__).resolve().parents[1]
KEY = b'fixture-only-not-production'
checks = 0
with tempfile.TemporaryDirectory(dir=ROOT / 'regression-tests') as tmp:
    base = pathlib.Path(tmp)
    classes = base / 'classes'; classes.mkdir()
    subprocess.run(['java', 'com.sun.tools.javac.Main', '-d', str(classes), *map(str, (ROOT/'src').rglob('*.java'))], check=True)
    def cli(db, *args):
        return subprocess.check_output(['java','-cp',str(classes),'bench.Main',str(db),*args], text=True).strip()
    def eq(actual, expected):
        global checks
        assert actual == expected, (actual, expected)
        checks += 1
    def fresh(name):
        db = base/name; eq(cli(db,'init'),'200 initialized'); return db
    def cb(db, seq, state, fault='none', id='r1', signature=None):
        seq = str(seq)
        sig = signature if signature is not None else hmac.new(KEY,f'{id}|{seq}|{state}'.encode(),hashlib.sha256).hexdigest()
        return cli(db,'callback',id,seq,state,sig,fault)
    def get(db, expected, id='r1'): eq(cli(db,'get',id),expected)
    # A01/A02: terminal invariance and one bill across distinct success events.
    db=fresh('terminal'); eq(cb(db,2,'SUCCEEDED'),'200 applied')
    for seq,state in [(1,'PROCESSING'),(3,'PROCESSING'),(4,'CANCELLED'),(5,'SUCCEEDED')]:
        eq(cb(db,seq,state),'200 stale'); get(db,'SUCCEEDED|1|false')
        eq(cb(db,seq,state),'200 duplicate')
    eq(cb(db,3,'FAILED'),'409 event_conflict'); get(db,'SUCCEEDED|1|false')
    eq(cb(db,6,'FAILED'),'409 manual_review'); get(db,'SUCCEEDED|1|true')
    eq(cb(db,6,'FAILED'),'200 duplicate')
    # A02: stale receipts and exact-body conflicts.
    db=fresh('stale'); eq(cb(db,5,'PROCESSING'),'200 applied')
    eq(cb(db,1,'CANCELLED'),'200 stale'); eq(cb(db,1,'FAILED'),'409 event_conflict')
    eq(cb(db,'05','PROCESSING'),'409 event_conflict')
    # A03/A05: rejection does not change persisted bytes.
    before=(db/'state.properties').read_bytes()
    for seq,state,sig,id,want in [('6','SUCCEEDED','bad','r1','401 invalid_signature'),('', 'SUCCEEDED',None,'r1','422 invalid_sequence'),('0','SUCCEEDED',None,'r1','422 invalid_sequence'),('-1','SUCCEEDED',None,'r1','422 invalid_sequence'),('2147483648','SUCCEEDED',None,'r1','422 invalid_sequence'),('6','INVALID',None,'r1','422 invalid_state'),('6','SUCCEEDED',None,'missing','404 unknown_refund')]:
        eq(cb(db,seq,state,id=id,signature=sig),want)
        eq((db/'state.properties').read_bytes(),before)
    # A04: before rollback; after durable receipt and single billing.
    db=fresh('faults'); before=(db/'state.properties').read_bytes()
    eq(cb(db,1,'SUCCEEDED','before'),'503 retry'); eq((db/'state.properties').read_bytes(),before)
    get(db,'PENDING|0|false'); eq(cb(db,1,'SUCCEEDED','after'),'503 response_lost')
    get(db,'SUCCEEDED|1|false'); eq(cb(db,1,'SUCCEEDED'),'200 duplicate')
    before=(db/'state.properties').read_bytes()
    eq(cb(db,2,'FAILED','before'),'503 retry'); eq((db/'state.properties').read_bytes(),before)
    eq(cb(db,2,'FAILED','after'),'503 response_lost'); get(db,'SUCCEEDED|1|true')
    eq(cb(db,2,'FAILED'),'200 duplicate')
    eq(cb(db,3,'PROCESSING','after'),'503 response_lost'); eq(cb(db,3,'PROCESSING'),'200 duplicate')
    # Review additions: ignored-before fault and old state-only receipt compatibility.
    before=(db/'state.properties').read_bytes()
    eq(cb(db,4,'CANCELLED','before'),'503 retry'); eq((db/'state.properties').read_bytes(),before)
    eq(cb(db,4,'CANCELLED'),'200 stale'); eq(cb(db,4,'FAILED'),'409 event_conflict')
    db=fresh('legacy')
    with (db/'state.properties').open('a') as f:
        f.write('\nr1.status=SUCCEEDED\nr1.seq=1\nr1.ledger=1\nr1.event.1=SUCCEEDED\n')
    eq(cb(db,1,'SUCCEEDED'),'200 duplicate'); get(db,'SUCCEEDED|1|false')
    eq(cb(db,1,'FAILED'),'409 event_conflict')
    # A05: success beats cancellation in either sequence direction.
    for seq in (1,3):
        db=fresh(f'cancel{seq}'); eq(cb(db,2,'CANCELLED'),'200 applied')
        eq(cb(db,seq,'SUCCEEDED'),'200 applied'); get(db,'SUCCEEDED|1|false')
    db=fresh('failure'); eq(cb(db,2,'FAILED'),'200 applied')
    eq(cb(db,3,'PROCESSING'),'200 stale'); eq(cb(db,4,'CANCELLED'),'200 stale')
    eq(cb(db,1,'SUCCEEDED'),'409 manual_review'); get(db,'FAILED|0|true')
    # Per-refund isolation and process-level lock contention.
    db=fresh('parallel')
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        results=list(pool.map(lambda _: cb(db,1,'SUCCEEDED'),range(12)))
    eq(results.count('200 applied'),1); eq(results.count('200 duplicate'),11)
    get(db,'SUCCEEDED|1|false'); get(db,'PENDING|0|false','r2')
    eq(cb(db,1,'SUCCEEDED',id='r2'),'200 applied'); get(db,'SUCCEEDED|1|false','r2')
print(f'PASS: {checks} assertions; fresh JVMs, atomic faults, concurrency and isolation')
