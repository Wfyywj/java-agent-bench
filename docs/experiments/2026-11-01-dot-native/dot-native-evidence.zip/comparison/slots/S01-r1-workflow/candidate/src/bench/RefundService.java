package bench;
public final class RefundService {
 public String callback(Store db,String id,String seqText,String next,String signature,String fault)throws Exception{
  String body=id+"|"+seqText+"|"+next;
  if(!Signature.valid(body,signature))return "401 invalid_signature";
  if(!db.get(id+".known","false").equals("true"))return "404 unknown_refund";
  int seq;try{seq=Integer.parseInt(seqText);if(seq<1)throw new NumberFormatException();}catch(NumberFormatException e){return "422 invalid_sequence";}
  if(!java.util.Set.of("PROCESSING","SUCCEEDED","FAILED","CANCELLED").contains(next))return "422 invalid_state";
  String old=db.get(id+".status","PENDING");String event=id+".event."+seq;
  String prior=db.get(event,"");
  // Old snapshots contain state-only receipts; new receipts retain the signed body too.
  if(!prior.isEmpty())return prior.equals(next)&&db.get(event+".body",body).equals(body)?"200 duplicate":"409 event_conflict";
  String result;
  boolean conflict=(old.equals("SUCCEEDED")&&next.equals("FAILED"))||(old.equals("FAILED")&&next.equals("SUCCEEDED"));
  boolean terminal=old.equals("SUCCEEDED")||old.equals("FAILED");
  boolean cancellationSuccess=old.equals("CANCELLED")&&next.equals("SUCCEEDED");
  if(conflict){
   db.set(id+".review",true);result="409 manual_review";
  }else if(terminal||(!cancellationSuccess&&seq<=db.number(id+".seq"))){
   result="200 stale";
  }else{
   db.set(id+".status",next);
   db.set(id+".seq",Math.max(seq,db.number(id+".seq")));
   if(next.equals("SUCCEEDED"))db.set(id+".ledger",1);
   result="200 applied";
  }
  // Even ignored events are receipts: a reused sequence cannot change its body.
  db.set(event,next);db.set(event+".body",body);
  if(fault.equals("before"))return "503 retry";
  db.commit();
  return fault.equals("after")?"503 response_lost":result;
 }
}
