# Local delivery
Changed src/bench/RefundService.java only among production sources. Main, Signature, Store and supplied public inputs are unchanged. Added requirement-decisions.md, evidence-map.md, regression-tests/run.py, workflow-trace.md and this note.

Verification: `python3 regression-tests/run.py` from candidate; installed Java 21 compiler module and Python 3, no dependencies/network. Final run passed 81 assertions. Initial attempt failed because javac binary was absent; runner now invokes the available compiler module. No assertions were removed or weakened.

Behavior changes: terminal protection, cancellation-to-success priority, once-per-refund billing, durable ignored receipts, exact-body conflicts for newly recorded events, and consistent review/ignored-event fault handling. Responses retain existing CLI shapes and codes. Replays use the existing duplicate response.

Limits: no hidden evaluator/selfcheck, CI, HTTP, production calls, database engine, power-loss/fsync guarantees or tenant isolation were tested. Legacy receipts contain state only, so their historical lexical body cannot be reconstructed. Existing corrupt/overcounted data is not automatically repaired. Store.before faults are modeled at CLI invocation boundaries, as required.

Recovery: stop local writers, retain a copy of state.properties, and restore code from the supplied snapshot if needed. Do not roll back projection state alone or replay real payments; reverting old code reintroduces ordering bugs. New receipt-body properties are additive and old Store parsing tolerates them. No commit, push, publish or external changes were performed.
