# Evidence map
Run from candidate: `python3 regression-tests/run.py`.
The runner compiles with installed Java 21's `com.sun.tools.javac.Main` and executes a new JVM for every CLI invocation. Temporary classes/state remain within regression-tests/ and are cleaned up.

| Acceptance | Implementation | Executed regression evidence |
|---|---|---|
| A01 | RefundService terminal guard and sequence comparison | success survives old/new processing, cancellation and repeated success; failure cannot regress |
| A02 | event receipt/body lookup, terminal-conflict flag, ledger=1 | duplicate/reused sequence, exact-body conflict, both terminal conflict orders, parallel duplicate callbacks, two-refund isolation |
| A03 | Signature.valid precedes mutations | invalid signature and invalid request leave state bytes unchanged; CLI output contains no secrets |
| A04 | shared before/commit/after branch; Store atomic move and lock | fresh JVM recovery from before/after faults for applied/review/ignored events; persisted snapshots unchanged before commit |
| A05 | cancellationSuccess override, sequence/id validation | cancellation followed by success at lower/higher sequence; empty/nonpositive/overflow sequence; unknown refund |

Review additions exercise ignored-before rollback and legacy state-only receipts. These tests reject arrival-order-only logic, success-event counting, ignored-event receipt omission and separate review fault handling. They do not prove network, database, production tenancy, fsync or arbitrary process-kill guarantees.
