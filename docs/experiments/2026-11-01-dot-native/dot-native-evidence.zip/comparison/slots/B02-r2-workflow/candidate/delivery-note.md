# Local delivery

Changed `src/ReturnService.java` only in production code: use persisted events for exact replay and payload conflict; permit only BORROWED for a fresh return. The HTTP API, data format, ownership checks, synchronization and atomic staged snapshot publication are preserved. No public input files changed.

Added `requirement-decisions.md`, `evidence-map.md`, `workflow-trace.md`, and `regression-tests/test_returns.py` with `results.txt`. The final suite compiled all Java sources and passed 6 tests in 13.971 seconds (exit 0), covering B02-A01–A05 as mapped in evidence-map.md. Review added live rollback/retry checks and damaged wrong-equipment corrected-return coverage; the final run includes both. The initial missing javac launcher was resolved using Java's installed compiler module, not a package install.

## Rollback
Stop the writer, back up its current snapshot, and revert the ReturnService code change to the prior deployed version if needed. No schema or snapshot-format migration is required. Rolling back reinstates the duplicate-job bug, so pause return traffic rather than accepting retries through the old implementation. Do not restore an older data snapshot over legitimate completed returns. Existing duplicate jobs from before this fix are not automatically repaired.

## Unverified and limits
This is local-only: no commit, push, PR, CI, deployment, or benchmark selfcheck/verifier was run. PostgreSQL transaction/constraint acceptance, two DB connections, fsync/power-loss durability, and multi-process writers remain unverified and outside the supplied adapter. Atomic rename and orderly restart tests do not establish crash durability. No availability scheduler exists here; damaged items stay REVIEW because this change never transitions them automatically. Production fault-header security is outside this synthetic fixture.
