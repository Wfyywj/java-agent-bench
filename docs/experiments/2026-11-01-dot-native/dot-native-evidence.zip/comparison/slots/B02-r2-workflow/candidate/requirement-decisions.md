# Requirements and decisions

## Provided business answers
The cabinet can retry after losing a response. A tenant-scoped token durably binds loan, equipment, damage, and the original success response. Exact replay must have no new writes; a changed binding conflicts. Unknown loans and tenant mismatch both return 404 NOT_FOUND. Fresh returns require the loan's equipment and BORROWED state. Normal returns produce CLEANING and one job; damaged returns produce REVIEW without a job. All staged writes roll back on fault 1, 2, or 3; two HTTP clients must be safe under one writer.

## Implementation decisions (not additional business rules)
Use the existing durable event as the replay record, after checking loan ownership and before checking current lifecycle. Compare all three payload fields. Retain the existing synchronized service method and snapshot commit rather than adding a cache or database. The adapter's HTTP identifiers exclude '/', so existing tenant/token keys are unambiguous. Failed and unauthorized requests do not reserve tokens. Ownership check precedes replay/conflict to preserve indistinguishable 404 responses, including a reused token targeting an inaccessible loan.

## Scope and unresolved items
Backend only; preserve HTTP API and snapshot format. No blocking clarification is needed: the frozen contract supplies the business answers. PostgreSQL constraints/transactions, multi-process writers, power-loss/fsync durability, and automatic cleaning completion are outside this adapter. No new cleanup or availability process is introduced.
