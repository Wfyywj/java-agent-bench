"""Run from any directory: python3 candidate/regression-tests/test_returns.py.
A03/A05 exercise the local snapshot adapter, not PostgreSQL.
"""
import concurrent.futures
import http.client
from pathlib import Path
import subprocess
import tempfile
import threading
import unittest
import urllib.parse

ROOT = Path(__file__).resolve().parents[1]

class Returns(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.build = tempfile.TemporaryDirectory(dir=ROOT / 'regression-tests')
        subprocess.run(['java', '-m', 'jdk.compiler/com.sun.tools.javac.Main', '-d', cls.build.name, *map(str, (ROOT / 'src').glob('*.java'))], check=True)

    @classmethod
    def tearDownClass(cls):
        cls.build.cleanup()

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=ROOT / 'regression-tests')
        self.snapshot = Path(self.tmp.name) / 'store.tsv'
        self.snapshot.write_bytes((ROOT / 'evidence/seed.tsv').read_bytes())
        self.start()

    def start(self):
        self.proc = subprocess.Popen(['java', '-Xmx96m', '-cp', self.build.name, 'App', str(self.snapshot)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        self.port = int(self.proc.stdout.readline().strip())

    def stop(self):
        self.proc.terminate()
        self.proc.communicate(timeout=10)

    def restart(self):
        self.stop()
        self.start()

    def tearDown(self):
        self.stop()
        self.tmp.cleanup()

    def request(self, fault=0, **changes):
        data = dict(tenant='tenantA', loan='loan1', token='cabinet77', equipment='bat1', damaged='false')
        data.update(changes)
        conn = http.client.HTTPConnection('127.0.0.1', self.port, timeout=5)
        try:
            conn.request('POST', '/returns', urllib.parse.urlencode(data), {'Content-Type': 'application/x-www-form-urlencoded', 'X-Test-Fault': str(fault)})
            response = conn.getresponse()
            return response.status, response.read().decode()
        finally:
            conn.close()

    def rows(self, kind):
        return [line.split('\t') for line in self.snapshot.read_text().splitlines() if line.startswith(kind + '\t')]

    def state(self, loan):
        return next(r[4] for r in self.rows('L') if r[1] == loan)

    def test_A01_replay_restart_and_second_token(self):
        expected = (200, 'loan=loan1;state=CLEANING')
        self.assertEqual(self.request(), expected)
        saved = self.snapshot.read_bytes()
        self.assertEqual(self.request(fault=1), expected)
        self.restart()
        self.assertEqual(self.request(), expected)
        self.assertEqual(self.request(token='fresh'), (409, 'NOT_RETURNABLE'))
        self.assertEqual(self.snapshot.read_bytes(), saved)
        self.assertEqual(self.state('loan1'), 'CLEANING')
        self.assertEqual(len(self.rows('E')), 1)
        self.assertEqual(self.rows('C'), [['C', 'loan1']])

    def test_A02_all_payload_conflicts_and_tenant_scope(self):
        self.assertEqual(self.request()[0], 200)
        saved = self.snapshot.read_bytes()
        for changes in [dict(equipment='other'), dict(damaged='true'), dict(loan='loan2', equipment='ball2')]:
            with self.subTest(changes=changes):
                self.assertEqual(self.request(**changes), (409, 'TOKEN_CONFLICT'))
                self.assertEqual(self.snapshot.read_bytes(), saved)
        self.restart()
        self.assertEqual(self.request(damaged='true'), (409, 'TOKEN_CONFLICT'))
        self.assertEqual(self.request(tenant='tenantB', loan='loan3', equipment='mat3'), (200, 'loan=loan3;state=CLEANING'))
        self.assertEqual(len(self.rows('E')), 2)
        self.assertEqual(len(self.rows('C')), 2)

    def test_A03_every_staged_failure_normal_and_damaged(self):
        # Restore a pristine snapshot only with the server stopped between cases.
        for damaged in ['false', 'true']:
            for fault in [1, 2, 3]:
                with self.subTest(damaged=damaged, fault=fault):
                    self.stop()
                    self.snapshot.write_bytes((ROOT / 'evidence/seed.tsv').read_bytes())
                    self.start()
                    before = self.snapshot.read_bytes()
                    self.assertEqual(self.request(damaged=damaged, fault=fault), (503, 'RETRY_LATER'))
                    self.assertEqual(self.snapshot.read_bytes(), before)
                    self.restart()
                    self.assertEqual(self.snapshot.read_bytes(), before)
                    state = 'REVIEW' if damaged == 'true' else 'CLEANING'
                    self.assertEqual(self.request(damaged=damaged), (200, 'loan=loan1;state=' + state))
                    self.assertEqual(self.state('loan1'), state)
                    self.assertEqual(len(self.rows('E')), 1)
                    self.assertEqual(len(self.rows('C')), int(damaged == 'false'))
                    # A different loan also verifies rollback in the still-running writer.
                    live_before = self.snapshot.read_bytes()
                    other = dict(loan='loan2', equipment='ball2', token='live', damaged=damaged)
                    self.assertEqual(self.request(fault=fault, **other), (503, 'RETRY_LATER'))
                    self.assertEqual(self.snapshot.read_bytes(), live_before)
                    self.assertEqual(self.request(**other), (200, 'loan=loan2;state=' + state))
                    self.assertEqual(self.state('loan2'), state)
                    self.assertEqual(len(self.rows('E')), 2)
                    self.assertEqual(len(self.rows('C')), 2 * int(damaged == 'false'))

    def test_A04_ownership_lifecycle_and_wrong_equipment(self):
        before = self.snapshot.read_bytes()
        for changes, expected in [
            (dict(tenant='tenantB'), (404, 'NOT_FOUND')),
            (dict(loan='missing'), (404, 'NOT_FOUND')),
            (dict(loan='loan4', equipment='cone4'), (409, 'NOT_RETURNABLE')),
            (dict(loan='loan5', equipment='net5'), (409, 'NOT_RETURNABLE')),
            (dict(equipment='ball2'), (409, 'NOT_RETURNABLE')),
            (dict(equipment='ball2', damaged='true'), (409, 'NOT_RETURNABLE')),
        ]:
            with self.subTest(changes=changes):
                self.assertEqual(self.request(**changes), expected)
                self.assertEqual(self.snapshot.read_bytes(), before)
        self.restart()
        self.assertEqual(self.snapshot.read_bytes(), before)
        expected = (200, 'loan=loan1;state=CLEANING')
        self.assertEqual(self.request(), expected)
        saved = self.snapshot.read_bytes()
        # Existing token must not turn cross-tenant or unknown access into a conflict.
        self.assertEqual(self.request(loan='loan3', equipment='mat3'), (404, 'NOT_FOUND'))
        self.assertEqual(self.request(loan='missing'), (404, 'NOT_FOUND'))
        self.restart()
        self.assertEqual(self.request(), expected)
        self.assertEqual(self.snapshot.read_bytes(), saved)

    def test_A04_damaged_wrong_equipment_corrected_same_token(self):
        before = self.snapshot.read_bytes()
        self.assertEqual(self.request(equipment='wrong', damaged='true'), (409, 'NOT_RETURNABLE'))
        self.assertEqual(self.snapshot.read_bytes(), before)
        self.restart()
        self.assertEqual(self.snapshot.read_bytes(), before)
        expected = (200, 'loan=loan1;state=REVIEW')
        self.assertEqual(self.request(damaged='true'), expected)
        saved = self.snapshot.read_bytes()
        self.restart()
        self.assertEqual(self.request(damaged='true'), expected)
        self.assertEqual(self.snapshot.read_bytes(), saved)
        self.assertEqual(self.state('loan1'), 'REVIEW')
        self.assertEqual(len(self.rows('E')), 1)
        self.assertEqual(self.rows('C'), [])

    def test_A05_parallel_replay_and_review(self):
        for damaged in ['false', 'true']:
            with self.subTest(damaged=damaged):
                self.stop()
                self.snapshot.write_bytes((ROOT / 'evidence/seed.tsv').read_bytes())
                self.start()
                barrier = threading.Barrier(2)
                def submit(_):
                    barrier.wait(timeout=5)
                    return self.request(damaged=damaged)
                state = 'REVIEW' if damaged == 'true' else 'CLEANING'
                expected = (200, 'loan=loan1;state=' + state)
                with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
                    self.assertEqual(list(pool.map(submit, range(2))), [expected, expected])
                saved = self.snapshot.read_bytes()
                self.assertEqual(self.state('loan1'), state)
                self.assertEqual(len(self.rows('E')), 1)
                self.assertEqual(len(self.rows('C')), int(damaged == 'false'))
                self.restart()
                self.assertEqual(self.request(damaged=damaged), expected)
                self.assertEqual(self.request(damaged=damaged, token='fresh'), (409, 'NOT_RETURNABLE'))
                self.assertEqual(self.snapshot.read_bytes(), saved)

if __name__ == '__main__':
    unittest.main(verbosity=2)
