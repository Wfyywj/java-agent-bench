# Workflow evidence

## 1. clarify-task
Read PROMPT.md, task.json, all three evidence inputs, and the four Java source files. Incident records two jobs after a replay; ReturnService reads `previous` but never uses it, and accepts CLEANING as a fresh return. Store already stages a copy and atomically replaces the snapshot; App shares one synchronized service across four HTTP workers. Output: requirement-decisions.md records scope, observable success/conflict/ownership/rollback behavior and provided answers versus implementation choices. No blocking business unknowns.

## 2. plain-plan
For a cabinet request, first confirm the loan belongs to the tenant. If the tenant/token event exists, compare its loan, equipment, and damage: replay the stored response or return conflict, with no writes. Otherwise require matching equipment and BORROWED state, then reuse existing staging and atomic publication. Change only ReturnService; preserve Store, App, Model and input evidence. Verify via independent standard-library HTTP clients, restart, exact snapshots and row counts; tests map to A01–A05. Database guarantees remain unverified.

## 3. implement-slice
Implemented durable replay and full payload comparison in ReturnService.submit, retaining ownership-first checks and synchronization. Fresh requests now require BORROWED instead of BORROWED-or-CLEANING. Existing staged writes, fault injection, persistent event loading and atomic snapshot replacement remain unchanged. Added a Python standard-library HTTP regression suite (regression-tests/test_returns.py) with fresh temporary fixture snapshots and Java compilation. No dependencies, external evaluator, repository state outside candidate, or remote actions are used.

## 4. verify-change
Initial test execution failed before any tests because `javac` is not on PATH (exit 5, zero tests). `java --version` confirms OpenJDK 21.0.12.1; `java --list-modules` confirms jdk.compiler. Switched the test compile command to the installed compiler module (`java -m jdk.compiler/com.sun.tools.javac.Main`), without downloading anything. Ran `python3 candidate/regression-tests/test_returns.py`: all 5 tests passed in 11.873 seconds, exit 0. Python syntax compilation passed. Tests observe HTTP results and persisted rows for A01–A05; these are local-adapter checks only.

## 5. review-change
Reviewed final ReturnService against original behavior and its App/Store callers: ownership remains before event lookup; all bound fields are compared; both CLEANING and REVIEW replay before lifecycle rejection; failed staging never mutates live Store; synchronized validation and commit protect both HTTP workers. No confirmed production-code defect remains within this scope. Planned SQL is not runtime evidence.
Review found two evidence gaps: rollback tests restarted before retry (not proving live memory rollback), and first-use wrong equipment lacked a damaged corrected-return case. Returned these to the implementation slice: added live post-fault replay and dedicated damaged wrong-equipment correction/restart coverage. Source behavior remains unchanged. Reverification results are recorded below.

Review-driven reverification: `python3 candidate/regression-tests/test_returns.py` compiled the final sources and passed all 6 tests in 13.971 seconds, exit 0 (regression-tests/results.txt). Both added evidence checks executed. No further production code changes were needed.

## 6. deliver-change
Produced delivery-note.md and evidence-map.md tying the final source and six regression tests to A01–A05, with rollback instructions and explicit infrastructure gaps. Final deliverable is the candidate directory only; no remote action or CI was applicable/claimed. Public evidence and input metadata are untouched. Removed generated Python bytecode; test build/snapshot directories self-cleaned. No learning or cross-trial memory retained.
