# Evidence map

| Acceptance | Supplied anchor / diagnosis | Implementation and regression evidence |
|---|---|---|
| B02-A01 | incident.log: one event but two jobs after response loss; original service ignored `previous` | ReturnService checks durable event before staging; test_A01 checks exact response, unchanged bytes, one event/job, restart replay, persisted CLEANING and fresh-token rejection |
| B02-A02 | PROMPT.md token binding; schema.sql event payload columns and tenant/token primary key | ReturnService compares loan, equipment, damage; test_A02 changes each independently, checks no writes, restart conflict and tenant-scoped token reuse |
| B02-A03 | schema.sql demands all writes share transaction; Store already stages then atomically replaces file | Existing Store.commit and service fail points retained; test_A03 faults 1/2/3 for normal and damaged returns, checks unchanged snapshot, restart and live retry, final state and counts |
| B02-A04 | seed.tsv provides other tenant, AVAILABLE, RETIRED; contract forbids incorrect equipment | Ownership check retained; fresh-state check narrowed to BORROWED. Both test_A04 cases check indistinguishable 404, unavailable/retired/wrong equipment rejection, unchanged bytes, restart, corrected same-token returns (normal and damaged), and durable replay |
| B02-A05 | schema.sql uniqueness is planned, not executed; App has four workers but one service | synchronized submit retained; test_A05 uses two connections released by a barrier, one event, expected job count, CLEANING or REVIEW, restart replay and fresh-token rejection |

Run: `python3 candidate/regression-tests/test_returns.py` from the slot root (or invoke the script by absolute path). The script compiles all candidate/src Java sources using the installed Java compiler module and uses temporary snapshots inside regression-tests. Final stdout/stderr: regression-tests/results.txt. Six tests passed; Python 3.12.14 and OpenJDK 21.0.12.1. These are self-authored regression checks, not the unavailable benchmark verifier.

A03 and A05 have only local-adapter evidence. No PostgreSQL, SQL constraints, two database connections, power-loss/fsync, multi-process locking, or hidden evaluation was exercised.
