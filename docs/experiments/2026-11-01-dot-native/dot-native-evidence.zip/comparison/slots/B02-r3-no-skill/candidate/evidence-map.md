# Evidence map

## Diagnosis before repair
- `evidence/incident.log`: synthetic lost-response replay yields two cleaning
  jobs and one event, consistent with overwriting the event map while appending
  jobs on every submission.
- `evidence/seed.tsv`: two BORROWED tenantA loans, one BORROWED tenantB loan,
  AVAILABLE loan4 and RETIRED loan5 supply ownership and lifecycle cases.
- `evidence/schema.sql`: `(tenant, token)` event key, unique cleaning loan, and
  shared transaction describe the intended future SQL boundary only.
- Original `src/ReturnService.java`: reads but ignores `previous`, accepts
  CLEANING as returnable, and appends another job. REVIEW rejects replay.
- `src/Store.java`: event records include bound payload and original result;
  loading restores them. Snapshot copying and atomic replacement already stage
  all effects before publication; the service lock spans reads and commit.

## Acceptance mapping
All tests are in `regression-tests/test_returns.py`; responses and persisted
snapshot rows/bytes are asserted, not merely logged.

| ID | Test | Evidence produced |
|---|---|---|
| B02-A01 | `test_A01_replay_restart_and_new_token` | Exact response, unchanged replay snapshot, process restart replay, CLEANING state, one event/job, second-token rejection |
| B02-A02 | `test_A02_binding_and_tenant_scope` | Equipment, damage and loan conflicts without writes; durable conflict; same token independently usable by tenantB |
| B02-A03 | `test_A03_faults_no_effect_retry_and_restart` | Fault stages 1/2/3 for normal and damaged returns yield 503, unchanged snapshot, restart and successful retry with correct cardinalities |
| B02-A04 | `test_A04_scope_and_lifecycle` | Identical ownership/unknown 404s; AVAILABLE/RETIRED rejection; wrong equipment for both flags, unchanged disk across restart, corrected same-token success and durable replay |
| B02-A05 | `test_A05_concurrent_normal_and_damaged` | Two separate HTTP connections released by a barrier; one event/job for normal return; REVIEW/no jobs for damaged return, durable replay, new-token rejection |

A03/A05 demonstrate local-adapter behavior only. No SQL transaction, database
uniqueness, two database sessions, fsync, or multiple writer process was tested.
