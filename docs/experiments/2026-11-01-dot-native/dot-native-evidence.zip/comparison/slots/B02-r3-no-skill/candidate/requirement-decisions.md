# Requirement decisions

## Supplied answers (not assumptions)
The frozen contract in PROMPT.md requires tenant-scoped tokens bound to loan,
equipment and damage flag; durable exact replay; conflicting payload rejection;
BORROWED-only first returns; CLEANING plus one job for normal returns; REVIEW
without a job for damaged returns; and atomic publication of all three records.
Tenant mismatch and unknown loans both return `404 NOT_FOUND`. The adapter has
one process/writer and may receive concurrent HTTP requests.

## Decisions and interpretation
1. Check loan existence and tenant ownership before inspecting token history.
   This preserves the explicit non-disclosure rule even when a supplied token
   exists. This precedence for overlapping errors is an interpretation, not a
   separate business answer.
2. For an owned loan, inspect the persisted event before equipment/state checks.
   Compare all three bound payload fields. Return its stored result on exact
   replay; return `409 TOKEN_CONFLICT` on any difference. In particular REVIEW
   and CLEANING states do not prevent replay of a successful return.
3. Only a previously unused token reaches first-return validation. Require both
   matching equipment and BORROWED state. A second token cannot return an item
   already in CLEANING/REVIEW. Rejected requests do not reserve tokens.
4. Preserve the synchronized service boundary and copy/stage/atomic-replace
   repository boundary. The existing service is the only writer in App. No
   in-memory replay cache or new persistence format is introduced.
5. Scope assumption: existing snapshots are structurally valid. This repair
   prevents new duplicates; it does not reconcile historical duplicate jobs.
   The input identifier alphabet excludes `/`, so the existing tenant/token
   string key is unambiguous for public HTTP requests.

No clarification was required. Planned SQL is design evidence, not a running
backend: a production SQL implementation still needs the stated transaction and
unique constraints. This change makes no database or power-loss guarantees.
