# Offline regressions
Run from candidate: `python3 regression-tests/test_returns.py`.

Uses only Python standard library and installed Java 21. Compilation invokes
`java -m jdk.compiler/com.sun.tools.javac.Main` because this environment lacks a
`javac` launcher although its compiler module is installed. Temporary build and
snapshot directories are created under candidate and automatically removed.
Public fixtures are read only. The literal `\t` delimiters in the public seed
are decoded into real tabs in each temporary runtime snapshot.

See ../evidence-map.md for the B02-A01–A05 test mapping. This is our own regression
suite, not the unavailable evaluator/selfcheck. HTTP concurrency uses distinct
connections in one server process, not multiple database connections.
