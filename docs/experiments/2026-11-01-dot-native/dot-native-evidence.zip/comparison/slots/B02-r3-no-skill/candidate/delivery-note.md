# Delivery note

## Changes
- `src/ReturnService.java`: use durable event history for exact replay and full
  payload conflict detection; restrict first returns to BORROWED. Preserve
  public request/response API, repository format, synchronized writer and
  atomic snapshot publication.
- Added requirement decisions, evidence map, regression suite and this note.
- Public input files, App, Model and Store are unchanged.

## Validation
`python3 regression-tests/test_returns.py` compiles the candidate using installed
Java 21 and exercises five mapped HTTP tests (including six fault subcases).
The initial attempt found no `javac` executable; the suite now invokes the
installed compiler module directly. See final test outcome below.

## Rollback
Stop the process and preserve its snapshot before reverting the scoped Java
change and recompiling/restarting. No data migration is needed: format is
unchanged. Reverting reintroduces duplicate-job risk, so keep return traffic
paused or use the fixed build. Do not blindly restore an old snapshot: that
would lose accepted returns. Historical duplicate jobs require a separately
authorized reconciliation, not automatic deletion by this patch.

## Unverified
No provided evaluator or selfcheck was available or run. No PostgreSQL execution,
SQL uniqueness, multi-process locking, power-loss/fsync durability, production
authentication, or historical-data reconciliation is claimed. The synthetic
fixtures and local HTTP tests do not establish full catalog infrastructure
acceptance. REVIEW persists and no automatic availability transition exists in
this adapter; future background processors are outside the supplied code.

Final outcome: all 5 tests passed, including repeated same-process fault
attempts and six normal/damaged × stage combinations. Tests also verify state
and record counts after actual server restarts.
