"""Offline HTTP regression suite. Run: python3 regression-tests/test_returns.py."""
import concurrent.futures
import http.client
from pathlib import Path
import subprocess
import tempfile
import threading
import unittest
import urllib.parse

ROOT = Path(__file__).resolve().parents[1]

class Returns(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.build = tempfile.TemporaryDirectory(dir=ROOT)
        subprocess.run(['java', '-m', 'jdk.compiler/com.sun.tools.javac.Main', '-d', cls.build.name,
                        *map(str, sorted((ROOT / 'src').glob('*.java')))], check=True)

    @classmethod
    def tearDownClass(cls):
        cls.build.cleanup()

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=ROOT)
        self.file = Path(self.temp.name) / 'snapshot.tsv'
        # Public seed uses literal backslash-t delimiters; runtime takes actual tabs.
        self.file.write_text((ROOT / 'evidence/seed.tsv').read_text().replace('\\t', '\t'))
        self.start()

    def start(self):
        self.proc = subprocess.Popen(['java', '-Xmx96m', '-cp', self.build.name,
                                      'App', str(self.file)], stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE, text=True)
        self.port = int(self.proc.stdout.readline().strip())

    def stop(self):
        self.proc.terminate()
        self.proc.communicate(timeout=10)

    def restart(self):
        self.stop()
        self.start()

    def tearDown(self):
        self.stop()
        self.temp.cleanup()

    def post(self, fault=0, **changes):
        fields = dict(tenant='tenantA', loan='loan1', token='cabinet77',
                      equipment='bat1', damaged='false')
        fields.update(changes)
        conn = http.client.HTTPConnection('127.0.0.1', self.port, timeout=10)
        try:
            conn.request('POST', '/returns', urllib.parse.urlencode(fields),
                         {'Content-Type': 'application/x-www-form-urlencoded',
                          'X-Test-Fault': str(fault)})
            response = conn.getresponse()
            return response.status, response.read().decode()
        finally:
            conn.close()

    def snapshot(self):
        return self.file.read_bytes()

    def assert_state(self, loan, state, events, jobs):
        rows = [line.split('\t') for line in self.file.read_text().splitlines()]
        self.assertEqual(next(r[4] for r in rows if r[:2] == ['L', loan]), state)
        self.assertEqual(sum(r[0] == 'E' and r[2] == loan for r in rows), events)
        self.assertEqual(sum(r[:2] == ['C', loan] for r in rows), jobs)

    def test_A01_replay_restart_and_new_token(self):
        original = self.post()
        self.assertEqual(original, (200, 'loan=loan1;state=CLEANING'))
        saved = self.snapshot()
        self.assertEqual(self.post(), original)
        self.assertEqual(self.snapshot(), saved)
        self.restart()
        self.assertEqual(self.post(), original)
        self.assertEqual(self.post(token='new'), (409, 'NOT_RETURNABLE'))
        self.assertEqual(self.snapshot(), saved)
        self.assert_state('loan1', 'CLEANING', 1, 1)

    def test_A02_binding_and_tenant_scope(self):
        self.assertEqual(self.post()[0], 200)
        saved = self.snapshot()
        for changes in [dict(equipment='ball2'), dict(damaged='true'),
                        dict(loan='loan2', equipment='ball2')]:
            self.assertEqual(self.post(**changes), (409, 'TOKEN_CONFLICT'))
            self.assertEqual(self.snapshot(), saved)
        self.restart()
        self.assertEqual(self.post(damaged='true'), (409, 'TOKEN_CONFLICT'))
        self.assertEqual(self.post(tenant='tenantB', loan='loan3', equipment='mat3'),
                         (200, 'loan=loan3;state=CLEANING'))
        self.assert_state('loan1', 'CLEANING', 1, 1)
        self.assert_state('loan3', 'CLEANING', 1, 1)

    def test_A03_faults_no_effect_retry_and_restart(self):
        for damaged in ('false', 'true'):
            for fault in (1, 2, 3):
                with self.subTest(damaged=damaged, fault=fault):
                    self.stop()
                    self.file.write_text((ROOT / 'evidence/seed.tsv').read_text().replace('\\t', '\t'))
                    self.start()
                    saved = self.snapshot()
                    self.assertEqual(self.post(fault=fault, damaged=damaged), (503, 'RETRY_LATER'))
                    self.assertEqual(self.snapshot(), saved)
                    # Same running service must still permit a first return: a
                    # second injected attempt must fail, not replay or reject.
                    self.assertEqual(self.post(fault=fault, damaged=damaged), (503, 'RETRY_LATER'))
                    self.assertEqual(self.snapshot(), saved)
                    self.restart()
                    self.assertEqual(self.snapshot(), saved)
                    result = self.post(damaged=damaged)
                    state = 'REVIEW' if damaged == 'true' else 'CLEANING'
                    self.assertEqual(result, (200, 'loan=loan1;state=' + state))
                    self.assertEqual(self.post(damaged=damaged), result)
                    self.assert_state('loan1', state, 1, int(damaged == 'false'))

    def test_A04_scope_and_lifecycle(self):
        saved = self.snapshot()
        for changes, expected in [
            (dict(tenant='tenantB'), (404, 'NOT_FOUND')),
            (dict(loan='missing'), (404, 'NOT_FOUND')),
            (dict(loan='loan4', equipment='cone4'), (409, 'NOT_RETURNABLE')),
            (dict(loan='loan5', equipment='net5'), (409, 'NOT_RETURNABLE')),
        ]:
            self.assertEqual(self.post(**changes), expected)
            self.assertEqual(self.snapshot(), saved)
        for damaged in ('false', 'true'):
            self.assertEqual(self.post(equipment='wrong', damaged=damaged), (409, 'NOT_RETURNABLE'))
            self.assertEqual(self.snapshot(), saved)
            self.restart()
            self.assertEqual(self.snapshot(), saved)
        result = self.post()
        self.assertEqual(result[0], 200)
        self.restart()
        self.assertEqual(self.post(), result)
        self.assertEqual(self.post(tenant='tenantB'), (404, 'NOT_FOUND'))
        self.assertEqual(self.post(loan='missing'), (404, 'NOT_FOUND'))
        self.assert_state('loan1', 'CLEANING', 1, 1)

    def concurrent_posts(self, **changes):
        barrier = threading.Barrier(2)
        def send():
            barrier.wait(timeout=10)
            return self.post(**changes)
        with concurrent.futures.ThreadPoolExecutor(2) as executor:
            futures = [executor.submit(send) for _ in range(2)]
            return [f.result(timeout=15) for f in futures]

    def test_A05_concurrent_normal_and_damaged(self):
        self.assertEqual(self.concurrent_posts(), [(200, 'loan=loan1;state=CLEANING')] * 2)
        self.assert_state('loan1', 'CLEANING', 1, 1)
        payload = dict(loan='loan2', equipment='ball2', token='damage', damaged='true')
        expected = (200, 'loan=loan2;state=REVIEW')
        self.assertEqual(self.concurrent_posts(**payload), [expected] * 2)
        self.assert_state('loan2', 'REVIEW', 1, 0)
        saved = self.snapshot()
        self.restart()
        self.assertEqual(self.post(**payload), expected)
        self.assertEqual(self.post(**{**payload, 'token': 'new'}), (409, 'NOT_RETURNABLE'))
        self.assertEqual(self.post(**{**payload, 'damaged': 'false'}), (409, 'TOKEN_CONFLICT'))
        self.assertEqual(self.snapshot(), saved)
        self.assert_state('loan2', 'REVIEW', 1, 0)

if __name__ == '__main__':
    unittest.main(verbosity=2)
