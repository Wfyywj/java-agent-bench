package bench;

public final class RefundService {
 public String callback(Store db,String id,String seqText,String next,String signature,String fault)throws Exception{
  if(!Signature.valid(id+"|"+seqText+"|"+next,signature))return "401 invalid_signature";
  if(!db.get(id+".known","false").equals("true"))return "404 unknown_refund";
  int seq;try{seq=Integer.parseInt(seqText);if(seq<1)throw new NumberFormatException();}catch(NumberFormatException e){return "422 invalid_sequence";}
  if(!java.util.Set.of("PROCESSING","SUCCEEDED","FAILED","CANCELLED").contains(next))return "422 invalid_state";
  String old=db.get(id+".status","PENDING");String event=id+".event."+seq;
  String prior=db.get(event,"");
  if(!prior.isEmpty())return prior.equals(next)?"200 duplicate":"409 event_conflict";

  int highWater=db.number(id+".seq");
  String result;
  // Money-final outcomes disagree: preserve the projection for manual reconciliation.
  if((old.equals("SUCCEEDED")&&next.equals("FAILED"))||(old.equals("FAILED")&&next.equals("SUCCEEDED"))){
   db.set(id+".review",true);
   result="409 manual_review";
  }else if((old.equals("SUCCEEDED")||old.equals("FAILED"))&&!old.equals(next)){
   // A later sequence alone cannot undo a terminal outcome or repeat its billing.
   result="200 stale";
  }else if(old.equals("CANCELLED")&&next.equals("SUCCEEDED")){
   apply(db,id,next);
   result="200 applied";
  }else if(seq<=highWater || (old.equals("CANCELLED")&&next.equals("PROCESSING"))){
   result="200 stale";
  }else{
   apply(db,id,next);
   result="200 applied";
  }
  // Receipts, high-water mark, review and projection share the same atomic snapshot.
  db.set(event,next);
  db.set(id+".seq",Math.max(seq,highWater));
  if(fault.equals("before"))return "503 retry";
  db.commit();
  return fault.equals("after")?"503 response_lost":result;
 }
 private void apply(Store db,String id,String next){
  db.set(id+".status",next);
  if(next.equals("SUCCEEDED")&&db.number(id+".ledger")==0)db.set(id+".ledger",1);
 }
}
