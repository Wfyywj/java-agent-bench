#!/usr/bin/env python3
"""Synthetic restart and concurrency tests; all scratch files stay inside candidate."""
import concurrent.futures
import hashlib
import hmac
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]

class RefundTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.build = tempfile.TemporaryDirectory(prefix='.test-build-', dir=ROOT)
        subprocess.run(['java', 'com.sun.tools.javac.Main', '-d', cls.build.name, *map(str, (ROOT/'src/bench').glob('*.java'))], check=True)
    @classmethod
    def tearDownClass(cls):
        cls.build.cleanup()
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='.test-state-', dir=ROOT)
        self.addCleanup(self.tmp.cleanup)
        self.assertEqual(self.cmd('init'), '200 initialized')
    def cmd(self, *args):
        return subprocess.run(['java', '-cp', self.build.name, 'bench.Main', self.tmp.name, *args], check=True, text=True, capture_output=True).stdout.strip()
    def callback(self, seq, state, fault='none', id='r1', signature=None):
        seq = str(seq)
        signature = signature if signature is not None else hmac.new(b'fixture-only-not-production', f'{id}|{seq}|{state}'.encode(), hashlib.sha256).hexdigest()
        return self.cmd('callback', id, seq, state, signature, fault)
    def projection(self, expected, id='r1'):
        self.assertEqual(self.cmd('get', id), expected)
    def test_A01_success_no_regression(self):
        self.callback(2, 'SUCCEEDED')
        for seq, state in [(1,'PROCESSING'), (3,'PROCESSING'), (4,'CANCELLED'), (5,'SUCCEEDED')]:
            self.callback(seq,state)
            self.projection('SUCCEEDED|1|false')
        self.assertEqual(self.callback(6,'SUCCEEDED'),'200 applied')
        self.projection('SUCCEEDED|1|false')
        self.projection('PENDING|0|false','r2')
    def test_A02_duplicate_and_body_conflict(self):
        self.assertEqual(self.callback(1,'SUCCEEDED'),'200 applied')
        self.assertEqual(self.callback(1,'SUCCEEDED'),'200 duplicate')
        self.assertEqual(self.callback(1,'FAILED'),'409 event_conflict')
        self.projection('SUCCEEDED|1|false')
    def test_A02_terminal_conflicts(self):
        for first, second, count in [('SUCCEEDED','FAILED',1), ('FAILED','SUCCEEDED',0)]:
            id = 'r1' if count else 'r2'
            self.callback(4,first,id=id)
            self.assertEqual(self.callback(2,second,id=id),'409 manual_review')
            self.projection(f'{first}|{count}|true',id)
            self.assertEqual(self.callback(2,second,id=id),'200 duplicate')
    def test_A03_rejects_are_nonmutating(self):
        path = Path(self.tmp.name)/'state.properties'
        before = path.read_bytes()
        cases = [('', 'SUCCEEDED', {}, '422 invalid_sequence'), ('0','SUCCEEDED',{},'422 invalid_sequence'), ('2147483648','SUCCEEDED',{},'422 invalid_sequence'), ('1','BOGUS',{},'422 invalid_state'), ('1','SUCCEEDED',{'id':'unknown'},'404 unknown_refund'), ('1','SUCCEEDED',{'signature':'bad'},'401 invalid_signature')]
        for seq,state,kwargs,expected in cases:
            self.assertEqual(self.callback(seq,state,**kwargs),expected)
            self.assertEqual(path.read_bytes(),before)
    def test_A04_before_and_after(self):
        self.assertEqual(self.callback(1,'SUCCEEDED','before'),'503 retry')
        self.projection('PENDING|0|false')
        self.assertEqual(self.callback(1,'SUCCEEDED','after'),'503 response_lost')
        self.projection('SUCCEEDED|1|false')
        self.assertEqual(self.callback(1,'SUCCEEDED'),'200 duplicate')
        self.assertEqual(self.callback(2,'FAILED','before'),'503 retry')
        self.projection('SUCCEEDED|1|false')
        self.assertEqual(self.callback(2,'FAILED','after'),'503 response_lost')
        self.projection('SUCCEEDED|1|true')
        self.assertEqual(self.callback(2,'FAILED'),'200 duplicate')
    def test_A04_stale_receipt_faults(self):
        self.callback(3,'PROCESSING')
        self.assertEqual(self.callback(1,'PROCESSING','before'),'503 retry')
        self.assertEqual(self.callback(1,'PROCESSING','after'),'503 response_lost')
        self.assertEqual(self.callback(1,'PROCESSING'),'200 duplicate')
        self.assertEqual(self.callback(1,'FAILED'),'409 event_conflict')
        self.projection('PROCESSING|0|false')
    def test_A05_cancel_success(self):
        self.callback(4,'CANCELLED')
        self.callback(5,'PROCESSING')
        self.projection('CANCELLED|0|false')
        self.callback(2,'SUCCEEDED')
        self.projection('SUCCEEDED|1|false')
    def test_A01_failed_no_regression(self):
        self.callback(1,'FAILED')
        self.callback(2,'PROCESSING')
        self.callback(3,'CANCELLED')
        self.projection('FAILED|0|false')
    def test_A02_concurrent_receipts(self):
        with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
            results = list(pool.map(lambda _: self.callback(1,'SUCCEEDED'),range(12)))
        self.assertEqual(results.count('200 applied'),1)
        self.assertEqual(results.count('200 duplicate'),11)
        self.projection('SUCCEEDED|1|false')
        with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
            list(pool.map(lambda seq: self.callback(seq,'SUCCEEDED'),range(2,14)))
        self.projection('SUCCEEDED|1|false')

if __name__ == '__main__':
    unittest.main(verbosity=2)
