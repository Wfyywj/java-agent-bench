# Requirements and decisions

The supplied executable PROMPT is authoritative over the older design-only infrastructure notes. No user answers were invented and no blocking clarification remains.

- S01-A01: SUCCESS is represented by SUCCEEDED; it cannot be replaced by PROCESSING or CANCELLED at any sequence. FAILED is likewise money-final. Ordinary transitions require a sequence above the persisted high-water mark.
- S01-A02: Receipt identity is refund ID plus parsed positive integer sequence. A different state at that identity returns 409 event_conflict without changing the first receipt or projection. Same identity/state returns 200 duplicate. Fresh SUCCEEDED/FAILED disagreement queues durable manual review, preserving the original projection, even for an older sequence. A refund's accepted success changes its ledger from zero to one exactly once.
- S01-A03: HMAC checks precede any business writes, preserving the fixture-only key and signature contract. No signature or key logging was added. Unknown refunds reject 404; invalid states and non-positive, missing, overflowing or malformed integer sequences reject 422.
- S01-A04: All fresh valid receipts, including ignored/stale events, are committed with the projection/review/high-water changes in one existing atomic snapshot. Before fault returns 503 without commit; after fault returns 503 after commit. Receipt replay is duplicate and cannot repeat the ledger effect. Assumes the existing CLI creates and closes one Store per invocation; no in-process reuse after an injected failed transaction is promised.
- S01-A05: Cancellation is a request, not proof money cannot move. A later delivered SUCCEEDED supersedes CANCELLED even when sequence order differs. Processing does not undo cancellation. SUCCEEDED/FAILED alone are conflicting money-final outcomes; cancellation is not such a conflict.

Implementation choices: retain a maximum observed sequence, not arrival order; record ignored events to prevent later identity reuse. Preserve all CLI argument shapes and existing response tokens. Fresh higher-sequence same-terminal-state callbacks remain `200 applied`, without additional billing. Existing fixture schema uses global refund IDs and no tenant field; no tenancy feature or production security claim is introduced.

Limits: no HTTP, real payment replay, database engine, distributed delivery, fsync/power-loss guarantees, migration of previously corrupted projections, production credentials or external services.
