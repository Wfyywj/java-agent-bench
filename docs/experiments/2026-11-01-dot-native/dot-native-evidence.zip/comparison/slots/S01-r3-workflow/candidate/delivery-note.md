# Local delivery

Changed src/bench/RefundService.java only in production code. Main, Store, Signature and supplied input files are unchanged. Added requirement-decisions.md, evidence-map.md, workflow-trace.md and regression-tests/.

The receiver now prevents terminal rollback, bills accepted success once, preserves stale event identity, flags conflicting money-final events and handles both injected fault points uniformly. Review additionally preserved the existing `200 applied` response for fresh same-state terminal notifications.

Validation: `python3 regression-tests/test_refunds.py` from candidate passed all 9 test methods after review, exit 0 (10.142 seconds); every callback/read/retry runs in a new JVM. Java 21.0.12.1, Python 3.12.14; no third-party packages. Compiler is invoked as `java com.sun.tools.javac.Main` because this environment lacks the `javac` launcher. Initial launcher failure ran no tests and was corrected, not ignored.

No commits, remote changes, PR, publishing or CI were requested or performed. External evaluator/hidden tests, real payment integration, OS power-loss behavior and production migrations were not tested. Only synthetic fixtures were used.

Deployment dependency: filesystem must support the existing atomic replacement and process file locks. No state schema migration is required; existing historical corruption is not repaired. To roll back, stop all CLI writers and restore the prior RefundService source/build; preserve state.properties rather than deleting receipt/billing history. Restoring old buggy behavior can reintroduce duplicate billing or terminal regression. Back up synthetic state before further experimentation; do not replay payment requests.
