# Evidence map

| Requirement | Source and executed evidence | Conclusion / alternative excluded |
|---|---|---|
| A01 | RefundService.callback terminal guard; test_A01_success_no_regression and test_A01_failed_no_regression | Neither a newer sequence nor later arrival alone can overwrite a terminal outcome. |
| A02 | RefundService receipt lookup, conflict branch and apply; test_A02_duplicate_and_body_conflict, test_A02_terminal_conflicts, test_A02_concurrent_receipts | Duplicate suppression alone is insufficient: distinct success sequences also must not duplicate the ledger. Concurrent subprocesses were tested under Store's lock. |
| A03 | Signature.valid; callback validation before mutation; test_A03_rejects_are_nonmutating | Invalid requests leave persisted snapshot bytes unchanged, not merely the visible status. No signature/key log added. |
| A04 | Store.commit atomic replacement; common callback commit path; test_A04_before_and_after, test_A04_stale_receipt_faults | After-commit faults persist receipts as well as projections/review; before-commit failures persist neither. Fresh JVM retries demonstrate restart durability within the stated filesystem scope. |
| A05 | cancellation branch; test_A05_cancel_success plus A03 validation | Cancellation cannot suppress observed success; missing sequence and unknown refund produce specified rejection. |

Reproduce from candidate: `python3 regression-tests/test_refunds.py`. It compiles all source files with the installed Java compiler module and starts a new JVM for every CLI call. Full final output: regression-tests/results.txt (9 passed, exit 0). Initial missing `javac` launcher and correction are recorded in workflow-trace.md. No supplied runnable public tests were present; no inaccessible selfcheck, evaluator or oracle was run. Real power loss, distributed messaging and production tenancy remain unverified and out of scope.
