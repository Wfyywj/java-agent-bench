# Requirement decisions

The executable prompt and existing CLI are binding; the older design-only JSON is context, not a requirement to add PostgreSQL or dispatch payments.

* Signed payload remains `refund|sequence|state` with the supplied synthetic fixture key. Invalid signatures, unknown refunds, invalid sequences and invalid states do not commit business changes.
* Refund identifiers scope receipts, high-water sequence, status, review and ledger. No tenant identity exists in this public CLI; tenant authorization cannot be invented here.
* An event sequence identifies an event within a refund. Same sequence/state is a duplicate; same sequence/different state is 409 conflict, without overwriting the original receipt.
* Opposing SUCCEEDED/FAILED reports queue durable manual review, even out of order, retaining the established status and ledger. A replay of that receipt returns the existing duplicate response, not another review action.
* SUCCEEDED cannot regress to PROCESSING/CANCELLED or charge the projection again on another SUCCEEDED. FAILED is also treated as terminal against nonterminal states.
* CANCELLED is a cancellation request, not a definitive financial failure: a newer SUCCEEDED supersedes it without manual review. A processing event does not undo cancellation. Sequence ordering applies to non-conflicting, previously unseen events; older events are receipted without changing the projection.
* Every accepted, previously unseen event, including stale/ignored events and review events, has an atomic receipt. Pre-commit fault returns 503 with no persistence; post-commit response loss returns 503 with receipt and projection persisted together.

No user clarification or answer was fabricated. Nonterminal ordering and failed-state absorption are explicit conservative assumptions based on the existing sequence contract and terminal-outcome policy. No genuine clarification blocks this isolated fixture implementation.
