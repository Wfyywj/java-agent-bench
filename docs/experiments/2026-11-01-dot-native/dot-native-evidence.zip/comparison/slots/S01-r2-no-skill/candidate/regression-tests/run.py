#!/usr/bin/env python3
"""Local synthetic CLI tests. Each command starts a new JVM."""
import hashlib, hmac, pathlib, subprocess, tempfile, itertools
ROOT = pathlib.Path(__file__).resolve().parents[1]
KEY = b'fixture-only-not-production'
checks = 0
with tempfile.TemporaryDirectory(dir=ROOT / 'regression-tests') as tmp:
    tmp = pathlib.Path(tmp)
    classes = tmp / 'classes'
    classes.mkdir()
    subprocess.run(['java', '-XX:-UsePerfData', '-m', 'jdk.compiler/com.sun.tools.javac.Main', '-d', str(classes), *map(str, (ROOT/'src/bench').glob('*.java'))], check=True)
    def run(db, *args):
        return subprocess.check_output(['java', '-XX:-UsePerfData', '-cp', str(classes), 'bench.Main', str(db), *args], text=True).strip()
    def eq(actual, expected):
        global checks
        assert actual == expected, (actual, expected)
        checks += 1
    def cb(db, seq, state, fault='none', id='r1', sig=None):
        seq = str(seq)
        if sig is None:
            sig = hmac.new(KEY, f'{id}|{seq}|{state}'.encode(), hashlib.sha256).hexdigest()
        return run(db, 'callback', id, seq, state, sig, fault)
    def fresh(name):
        db = tmp/name
        eq(run(db, 'init'), '200 initialized')
        return db
    # A01/A02: success is absorbing; billing once even across distinct events.
    db = fresh('terminal')
    eq(cb(db, 2, 'SUCCEEDED'), '200 applied')
    eq(cb(db, 1, 'PROCESSING'), '200 stale')
    eq(cb(db, 1, 'PROCESSING'), '200 duplicate')
    eq(cb(db, 1, 'CANCELLED'), '409 event_conflict')
    for seq, state in [(3,'PROCESSING'), (4,'CANCELLED'), (5,'SUCCEEDED')]:
        eq(cb(db, seq, state), '200 applied')
        eq(run(db, 'get', 'r1'), 'SUCCEEDED|1|false')
    eq(cb(db, 6, 'FAILED'), '409 manual_review')
    eq(run(db, 'get', 'r1'), 'SUCCEEDED|1|true')
    eq(run(db, 'get', 'r2'), 'PENDING|0|false')
    # A03/A05: authentication and validation do not mutate durable data.
    before = (db/'state.properties').read_bytes()
    eq(cb(db, 7, 'SUCCEEDED', sig='00'), '401 invalid_signature')
    eq(cb(db, '', 'SUCCEEDED'), '422 invalid_sequence')
    eq(cb(db, 0, 'SUCCEEDED'), '422 invalid_sequence')
    eq(cb(db, 7, 'BOGUS'), '422 invalid_state')
    eq(cb(db, 7, 'SUCCEEDED', id='unknown'), '404 unknown_refund')
    eq((db/'state.properties').read_bytes(), before)
    # A04: failure before and after atomic replacement, replay after restart.
    db = fresh('fault')
    eq(cb(db, 1, 'SUCCEEDED', 'before'), '503 retry')
    eq(run(db, 'get', 'r1'), 'PENDING|0|false')
    eq(cb(db, 1, 'SUCCEEDED', 'after'), '503 response_lost')
    eq(cb(db, 1, 'SUCCEEDED'), '200 duplicate')
    eq(run(db, 'get', 'r1'), 'SUCCEEDED|1|false')
    eq(cb(db, 2, 'FAILED', 'before'), '503 retry')
    eq(run(db, 'get', 'r1'), 'SUCCEEDED|1|false')
    eq(cb(db, 2, 'FAILED', 'after'), '503 response_lost')
    eq(cb(db, 2, 'FAILED'), '200 duplicate')
    eq(run(db, 'get', 'r1'), 'SUCCEEDED|1|true')
    # A05: cancellation is not evidence that refund cannot succeed.
    db = fresh('cancel')
    eq(cb(db, 1, 'CANCELLED'), '200 applied')
    eq(cb(db, 2, 'SUCCEEDED'), '200 applied')
    eq(run(db, 'get', 'r1'), 'SUCCEEDED|1|false')
    # A02: conflicting success does not invent a ledger entry on a failed refund.
    db = fresh('failed')
    eq(cb(db, 2, 'FAILED'), '200 applied')
    eq(cb(db, 3, 'PROCESSING'), '200 applied')
    eq(cb(db, 1, 'SUCCEEDED'), '409 manual_review')
    eq(run(db, 'get', 'r1'), 'FAILED|0|true')
    # Receipt durability includes ignored old events, not only applied transitions.
    db = fresh('stale-fault')
    eq(cb(db, 5, 'SUCCEEDED'), '200 applied')
    eq(cb(db, 1, 'PROCESSING', 'before'), '503 retry')
    eq(cb(db, 1, 'PROCESSING', 'after'), '503 response_lost')
    eq(cb(db, 1, 'FAILED'), '409 event_conflict')
    eq(cb(db, 1, 'PROCESSING'), '200 duplicate')
    eq(run(db, 'get', 'r1'), 'SUCCEEDED|1|false')
    # All delivery permutations of two success receipts and an older processing event.
    for index, events in enumerate(itertools.permutations([(1, 'PROCESSING'), (2, 'SUCCEEDED'), (3, 'SUCCEEDED')])):
        db = fresh('permutation-' + str(index))
        for seq, state in events:
            cb(db, seq, state)
        eq(run(db, 'get', 'r1'), 'SUCCEEDED|1|false')
    # Serialized cross-process delivery of the same event.
    db = fresh('concurrent')
    sig = hmac.new(KEY, b'r1|1|SUCCEEDED', hashlib.sha256).hexdigest()
    commands = [subprocess.Popen(['java','-XX:-UsePerfData','-cp',str(classes),'bench.Main',str(db),'callback','r1','1','SUCCEEDED',sig,'none'], stdout=subprocess.PIPE, text=True) for _ in range(8)]
    outputs = [p.communicate()[0].strip() for p in commands]
    eq(outputs.count('200 applied'), 1)
    eq(outputs.count('200 duplicate'), 7)
    eq(run(db, 'get', 'r1'), 'SUCCEEDED|1|false')
print(f'PASS: {checks} assertions; fresh JVM per command')
