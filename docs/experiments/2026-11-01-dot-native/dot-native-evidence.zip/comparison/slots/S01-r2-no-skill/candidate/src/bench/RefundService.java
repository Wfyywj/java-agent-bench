package bench;

import java.util.Properties;
import java.util.Set;

public final class RefundService {
 public String callback(Store db,String id,String seqText,String next,String signature,String fault)throws Exception {
  if(!Signature.valid(id+"|"+seqText+"|"+next,signature))return "401 invalid_signature";
  if(!db.get(id+".known","false").equals("true"))return "404 unknown_refund";
  int seq;
  try {seq=Integer.parseInt(seqText);if(seq<1)throw new NumberFormatException();}
  catch(NumberFormatException e){return "422 invalid_sequence";}
  if(!Set.of("PROCESSING","SUCCEEDED","FAILED","CANCELLED").contains(next))return "422 invalid_state";
  String event=id+".event."+seq;
  String prior=db.get(event,"");
  if(!prior.isEmpty())return prior.equals(next)?"200 duplicate":"409 event_conflict";

  // A receipt, its projection and the review flag form one persisted unit.
  // Also restore the working copy on an injected pre-commit failure so that
  // reusing a Store is as safe as the CLI's new-process replay.
  Properties before=new Properties();before.putAll(db.data);
  String old=db.get(id+".status","PENDING");
  boolean conflict=(old.equals("SUCCEEDED")&&next.equals("FAILED"))
      ||(old.equals("FAILED")&&next.equals("SUCCEEDED"));
  String response;
  db.set(event,next);
  if(conflict){
   db.set(id+".review",true);
   response="409 manual_review";
  } else if(seq<=db.number(id+".seq")){
   response="200 stale";
  } else {
   // A high sequence is not permission to undo a terminal outcome.
   boolean blocked=old.equals("SUCCEEDED")||old.equals("FAILED")
       ||(old.equals("CANCELLED")&&next.equals("PROCESSING"));
   db.set(id+".seq",seq);
   if(!blocked){
    db.set(id+".status",next);
    if(next.equals("SUCCEEDED"))db.set(id+".ledger",db.number(id+".ledger")+1);
   }
   response="200 applied";
  }
  if(fault.equals("before")){
   db.data.clear();db.data.putAll(before);
   return "503 retry";
  }
  try {db.commit();}catch(Exception e){db.data.clear();db.data.putAll(before);throw e;}
  return fault.equals("after")?"503 response_lost":response;
 }
}
