# Delivery

Changed `src/bench/RefundService.java`; added requirement-decisions.md, evidence-map.md and regression-tests/run.py. Public input materials, Main CLI, Signature and Store are unchanged.

The patch prevents terminal regressions and repeated billing on distinct success receipts, persists ignored-event receipts, applies fault injection uniformly to manual review and stale paths, and restores the working snapshot on pre-commit failure. Existing command arguments and output forms are retained.

## Verification

Executed `python3 candidate/regression-tests/run.py` with OpenJDK 21.0.12.1: PASS, 63 assertions; includes restart replay, pre/post-commit failures, conflicts, validation, ordering permutations and concurrent JVM delivery. Initial attempt could not find a `javac` launcher; the regression runner now compiles via the installed `jdk.compiler/com.sun.tools.javac.Main` module, and the full suite passed. An intermediate run encountered a JVM performance-data file collision warning contaminating stdout in the shared host; tests now disable JVM performance counters (`-XX:-UsePerfData`) rather than ignoring output.

No supplied benchmark selfcheck, trusted verifier, hidden tests, real payments, network calls or production integration were run. OS power-loss/fsync behavior, distributed delivery, HTTP, tenant authorization and database transactions are outside scope. Receipt retention is unbounded in this small fixture. Manual review is represented by the existing durable flag, not an external queue.

## Recovery

Requires local Java 21 (including compiler module for tests) and Python 3. State remains the original Properties schema, under the original file lock and atomic-replacement mechanism. Back up the synthetic state directory while commands are stopped before replacing code. Roll back the source and recompile if necessary; do not delete receipts or replay real payment requests. Reverting code restores the original defects; it cannot automatically repair any pre-existing incorrect ledger values. Atomic rename support is required; no non-atomic fallback is introduced.
