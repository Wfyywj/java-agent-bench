# Evidence map

| Requirement | Implementation / evidence | Alternative excluded |
| --- | --- | --- |
| S01-A01 monotonic status | `RefundService.callback` terminal guard and sequence comparison; terminal/permutation tests | Sequence alone permits a newer processing callback to regress success. |
| S01-A02 exactly-once projection, conflict review | Receipt lookup before transition; ledger changes only on entry to success; explicit opposed terminal check; terminal, failed and concurrent tests | Event deduplication alone cannot prevent two different successful event sequences from double counting. |
| S01-A03 authentication | Existing `Signature.valid`, called before mutations; validation test compares exact persisted bytes | Signed syntax alone is not sufficient: known refund, sequence and state must also pass validation. No signature/key logging was introduced. |
| S01-A04 durable atomicity | Existing `Store.commit` writes one Properties snapshot then atomic rename under process lock; callback funnels stale, applied and review outcomes through commit; fault tests | Acknowledging a stale event without persisting its identity allows a later conflicting body to bypass detection. Review branches must also simulate post-commit response loss. |
| S01-A05 cancellation and invalid input | cancellation tests, empty/zero sequence and unknown-refund tests | Cancellation does not forbid a later actual success. |

Local reproduction: `python3 candidate/regression-tests/run.py` from the slot root (or `python3 regression-tests/run.py` from candidate). Uses Java 21 compiler module without external dependencies. Each command is a new JVM. Includes eight simultaneous CLI writers and six event-order permutations. Tests are authored regression assertions, not an independent oracle or hidden acceptance result.
