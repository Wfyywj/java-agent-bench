# Workflow trace

## 1. clarify-task
Read PROMPT.md, task.json, all four src files and incident.log/schema.sql/seed.tsv. Observed that ReturnService reads but ignores `previous`, accepts CLEANING for a fresh return, and overwrites the event while appending a second job. Store already stages all records and atomically renames before publishing memory; submit is synchronized. App exposes faults and four HTTP worker threads. Concrete decisions and acceptance scope are recorded in requirement-decisions.md; no clarification is needed.

## 2. plain-plan
A cabinet's first valid return will use the existing staged snapshot commit. A retry will first verify tenant ownership, then return the saved event result only when all bound fields match. A mismatched token payload returns 409; a new token cannot return CLEANING/REVIEW. This limits Java changes to ReturnService and preserves Store's transaction boundary and disk format. Verify using a local Python stdlib HTTP harness that compiles Java, launches isolated snapshots, inspects disk and restarts processes. Map tests to A01 replay/restart; A02 three binding conflicts and tenant scoping; A03 all fault stages; A04 authorization/lifecycle/equipment; A05 concurrent clients and damaged review. No external evaluation or infrastructure claims.

## 3. implement-slice
Changed only ReturnService.java in production code: persisted event payload comparison plus replay before BORROWED-only first return validation. Existing App/Model/Store interfaces and persistence are unchanged. Added six HTTP regression methods covering all five acceptance IDs, disk state, process restart, both damage branches, fault rollback and separate connections. No repository-level git inspection was used because it could cross the expressly restricted slot; initial supplied sources were inspected directly and no preexisting edits were overwritten except the targeted method lines.

## 4. verify-change
Environment: OpenJDK 21.0.12.1, Python 3.12.14. First test attempt failed before any tests: `javac` executable was absent (exit 5, zero tests). Checked available Java modules and found jdk.compiler. Updated the harness to invoke the installed compiler using `java -m jdk.compiler/com.sun.tools.javac.Main`; no installation or dependency download. `python3 candidate/regression-tests/test_returns.py` then compiled all sources and passed six tests in 14.405 seconds (exit 0). This is local adapter evidence only; no unavailable selfcheck/verifier executed.

## 5. review-change
Reviewed the final submit method against the original inspected implementation and App/Store callers. Authorization precedes token lookup, comparison binds all three payload fields, durable replay cannot append jobs, and fresh tokens cannot re-return CLEANING or REVIEW. Synchronization still encompasses read/check/stage/commit, and all injected failures precede commit. No production defect found within the promised single-writer adapter. Review identified two evidence improvements: synchronize client start with a barrier, and explicitly restart after a staged failure before the successful retry. Implemented both in the test harness; production code unchanged. Full SQL acceptance and power-loss guarantees remain unverified by design.

Review rerun: `python3 candidate/regression-tests/test_returns.py > candidate/regression-tests/results.txt 2>&1` completed exit 0; all six tests passed after the barrier and pre-retry restart additions. Results are tied to the final source and test files.

## 6. deliver-change
Delivered locally in candidate/: scoped ReturnService change, six-method HTTP regression suite and its final results, requirement decisions, evidence map, delivery note and this trace. Rechecked final test completion and file inventory. Public prompt/metadata/evidence files remain unchanged. delivery-note.md provides rollback and explicitly lists unverified infrastructure and CI. No Git, remote publication, unavailable evaluator, reference solution or cross-trial data was used. No additional authorization or business clarification is needed for this local delivery.
