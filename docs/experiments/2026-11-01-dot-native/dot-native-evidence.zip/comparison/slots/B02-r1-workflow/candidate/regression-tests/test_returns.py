"""Offline HTTP regressions; run python3 regression-tests/test_returns.py from candidate."""
import concurrent.futures
import contextlib
import http.client
from pathlib import Path
import subprocess
import tempfile
import threading
import unittest
import urllib.parse

ROOT = Path(__file__).resolve().parents[1]

class Returns(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.build = tempfile.TemporaryDirectory(dir=ROOT)
        subprocess.run(['java', '-m', 'jdk.compiler/com.sun.tools.javac.Main', '-d', cls.build.name, *map(str, (ROOT/'src').glob('*.java'))], check=True)

    @classmethod
    def tearDownClass(cls):
        cls.build.cleanup()

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=ROOT)
        self.db = Path(self.tmp.name)/'store.tsv'
        self.db.write_bytes((ROOT/'evidence/seed.tsv').read_bytes())
        self.start()

    def tearDown(self):
        self.stop()
        self.tmp.cleanup()

    def start(self):
        self.proc = subprocess.Popen(['java', '-Xmx96m', '-cp', self.build.name, 'App', str(self.db)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        self.port = int(self.proc.stdout.readline().strip())

    def stop(self):
        self.proc.terminate()
        self.proc.communicate(timeout=10)

    def restart(self):
        self.stop()
        self.start()

    def post(self, fault=0, **changes):
        fields = dict(tenant='tenantA', loan='loan1', token='cabinet77', equipment='bat1', damaged='false')
        fields.update(changes)
        with contextlib.closing(http.client.HTTPConnection('127.0.0.1', self.port, timeout=10)) as c:
            c.request('POST', '/returns', urllib.parse.urlencode(fields), {'Content-Type':'application/x-www-form-urlencoded', 'X-Test-Fault':str(fault)})
            r = c.getresponse()
            return r.status, r.read().decode()

    def snapshot(self):
        return self.db.read_bytes()

    def state(self, loan, expected, events, jobs):
        rows = [line.split('\t') for line in self.db.read_text().splitlines()]
        self.assertEqual(next(r[4] for r in rows if r[0]=='L' and r[1]==loan), expected)
        self.assertEqual(sum(r[0]=='E' for r in rows), events)
        self.assertEqual(sum(r[0]=='C' for r in rows), jobs)

    def test_B02_A01_replay_restart_new_token(self):
        expected = (200,'loan=loan1;state=CLEANING')
        self.assertEqual(self.post(), expected)
        saved = self.snapshot()
        self.assertEqual(self.post(), expected)
        self.assertEqual(self.snapshot(), saved)
        self.restart()
        self.assertEqual(self.post(), expected)
        self.assertEqual(self.post(token='other'), (409,'NOT_RETURNABLE'))
        self.assertEqual(self.snapshot(), saved)
        self.state('loan1','CLEANING',1,1)

    def test_B02_A02_binding_and_tenant_scope(self):
        self.assertEqual(self.post()[0],200)
        saved = self.snapshot()
        for changes in ({'equipment':'ball2'}, {'damaged':'true'}, {'loan':'loan2','equipment':'ball2'}):
            self.assertEqual(self.post(**changes),(409,'TOKEN_CONFLICT'))
            self.assertEqual(self.snapshot(),saved)
        self.restart()
        self.assertEqual(self.post(damaged='true'),(409,'TOKEN_CONFLICT'))
        self.assertEqual(self.post(tenant='tenantB',loan='loan3',equipment='mat3'),(200,'loan=loan3;state=CLEANING'))
        self.state('loan3','CLEANING',2,2)

    def test_B02_A03_each_fault_atomic_retry(self):
        seed = (ROOT/'evidence/seed.tsv').read_bytes()
        for damaged in ('false','true'):
            for fault in (1,2,3):
                with self.subTest(damaged=damaged,fault=fault):
                    self.stop()
                    self.db.write_bytes(seed)
                    self.start()
                    self.assertEqual(self.post(fault=fault,damaged=damaged),(503,'RETRY_LATER'))
                    self.assertEqual(self.snapshot(),seed)
                    # A second staged failure exercises unchanged in-memory state;
                    # restart before success also proves rollback is durable.
                    self.assertEqual(self.post(fault=fault,damaged=damaged),(503,'RETRY_LATER'))
                    self.assertEqual(self.snapshot(),seed)
                    self.restart()
                    self.assertEqual(self.snapshot(),seed)
                    self.assertEqual(self.post(damaged=damaged)[0],200)
                    saved = self.snapshot()
                    self.restart()
                    self.assertEqual(self.post(damaged=damaged)[0],200)
                    self.assertEqual(self.snapshot(),saved)
                    self.state('loan1','REVIEW' if damaged=='true' else 'CLEANING',1,0 if damaged=='true' else 1)

    def test_B02_A04_authorization_lifecycle(self):
        saved = self.snapshot()
        for changes, expected in [({'tenant':'tenantB'},(404,'NOT_FOUND')), ({'loan':'missing'},(404,'NOT_FOUND')), ({'loan':'loan4','equipment':'cone4'},(409,'NOT_RETURNABLE')), ({'loan':'loan5','equipment':'net5'},(409,'NOT_RETURNABLE'))]:
            self.assertEqual(self.post(**changes),expected)
            self.assertEqual(self.snapshot(),saved)
        self.assertEqual(self.post()[0],200)
        saved = self.snapshot()
        self.assertEqual(self.post(loan='loan3',equipment='mat3'),(404,'NOT_FOUND'))
        self.assertEqual(self.snapshot(),saved)

    def test_B02_A04_wrong_equipment_corrected_same_token(self):
        for damaged in ('false','true'):
            with self.subTest(damaged=damaged):
                self.stop()
                self.db.write_bytes((ROOT/'evidence/seed.tsv').read_bytes())
                self.start()
                saved = self.snapshot()
                self.assertEqual(self.post(equipment='ball2',damaged=damaged),(409,'NOT_RETURNABLE'))
                self.assertEqual(self.snapshot(),saved)
                self.restart()
                self.assertEqual(self.snapshot(),saved)
                result = self.post(damaged=damaged)
                self.assertEqual(result,(200,'loan=loan1;state='+('REVIEW' if damaged=='true' else 'CLEANING')))
                saved = self.snapshot()
                self.restart()
                self.assertEqual(self.post(damaged=damaged),result)
                self.assertEqual(self.snapshot(),saved)

    def test_B02_A05_concurrent_normal_and_review(self):
        for damaged in ('false','true'):
            with self.subTest(damaged=damaged):
                self.stop()
                self.db.write_bytes((ROOT/'evidence/seed.tsv').read_bytes())
                self.start()
                barrier = threading.Barrier(2)
                def simultaneous(_):
                    barrier.wait(timeout=10)
                    return self.post(damaged=damaged)
                with concurrent.futures.ThreadPoolExecutor(2) as pool:
                    results = list(pool.map(simultaneous, range(2)))
                state = 'REVIEW' if damaged=='true' else 'CLEANING'
                self.assertEqual(results,[(200,'loan=loan1;state='+state)]*2)
                self.state('loan1',state,1,0 if damaged=='true' else 1)
                saved = self.snapshot()
                self.restart()
                self.assertEqual(self.post(damaged=damaged),results[0])
                self.assertEqual(self.post(token='new',damaged=damaged),(409,'NOT_RETURNABLE'))
                self.assertEqual(self.snapshot(),saved)

if __name__ == '__main__':
    unittest.main(verbosity=2)
