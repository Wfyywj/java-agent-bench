# Evidence map

Public evidence: incident.log identifies duplicate jobs on cabinet replay; schema.sql expresses the intended tenant/token event key, loan job key and shared transaction (design only); seed.tsv supplies BORROWED, AVAILABLE, RETIRED and cross-tenant examples. ReturnService is the business boundary; Store is the snapshot durability boundary; App exercises it through concurrent loopback HTTP connections.

| Acceptance | Regression methods in regression-tests/test_returns.py | Assertions |
|---|---|---|
| B02-A01 | test_B02_A01_replay_restart_new_token | Exact response replay, snapshot unchanged, one event/job, persisted CLEANING, second-token rejection |
| B02-A02 | test_B02_A02_binding_and_tenant_scope | Equipment/damage/loan conflicts without writes, restart conflict, same token in another tenant succeeds |
| B02-A03 | test_B02_A03_each_fault_atomic_retry | Stages 1/2/3 for normal and damaged branches; repeated 503, unchanged bytes, restart rollback, retry and durable replay |
| B02-A04 | test_B02_A04_authorization_lifecycle; test_B02_A04_wrong_equipment_corrected_same_token | Foreign/unknown 404, unavailable/retired and wrong equipment 409, unchanged snapshots, restart, corrected same-token success |
| B02-A05 | test_B02_A05_concurrent_normal_and_review | Barrier-started two independent connections; one event and normal job, REVIEW with zero jobs; restart replay and new-token rejection |

Run from candidate: `python3 regression-tests/test_returns.py`. The harness compiles using the installed Java compiler module and creates/removes all working snapshots and classes under candidate. Latest complete output is regression-tests/results.txt. This is not PostgreSQL, two database connections or proof of actual SQL unique constraints.
