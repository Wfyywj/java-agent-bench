# Local delivery

Changed src/ReturnService.java to replay persisted exact tokens, reject payload conflicts and allow new returns only from BORROWED. Public API, snapshot schema and App/Model/Store are unchanged. Added requirement-decisions.md, evidence-map.md, workflow-trace.md and regression-tests/test_returns.py with captured output in regression-tests/results.txt.

Verification: six HTTP regression tests cover B02-A01–A05, compiling Java 21 sources using the installed jdk.compiler module. See results.txt for the final rerun after review. The first attempt failed because the javac executable was absent; it was resolved without installing software. No external verifier or benchmark selfcheck was run.

Rollback: stop the adapter writer, restore the prior ReturnService.java and rebuild with the same Java compiler. No data migration is required because the disk schema is unchanged. Rolling back reintroduces duplicate-return behavior; stop retry traffic or forward-fix instead if service must remain active. Do not restore old snapshots blindly, which would discard accepted returns. Existing duplicate historical jobs are not repaired.

Unverified/out of scope: PostgreSQL integration, SQL uniqueness, two database connections, fsync/power-loss crash durability, multi-process locking, production authorization, external CI and hidden evaluation. Local-only delivery: no commit, push, publishing or PR. A03/A05 are local-adapter evidence, not full catalog infrastructure acceptance.
