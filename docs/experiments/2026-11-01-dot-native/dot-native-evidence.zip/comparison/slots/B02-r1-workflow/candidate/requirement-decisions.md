# Requirement decisions

## Provided answers
The cabinet retries after a lost response; the incident records two jobs and one event. Repair only the local Java backend, retaining POST parameters, response format, file schema and public API. The frozen prompt requires tenant-scoped durable tokens bound to loan/equipment/damage, exact replay, payload conflict, tenant non-disclosure, BORROWED-only first returns, CLEANING with one job or REVIEW with no job, atomic publication, restart and concurrent HTTP support. Acceptance IDs and coverage come from task.json.

## Implementation decisions / assumptions
Resolve loan ownership before looking up its tenant-scoped token so unknown or foreign loans always remain indistinguishable 404s. For an owned loan, compare a previously used token before equipment/lifecycle validation: changed payload is TOKEN_CONFLICT; exact replay returns the persisted result even if no longer BORROWED. A fresh token may only return a BORROWED loan. The existing synchronized service is the one writer promised by the prompt; its copied Store plus atomic rename already provides the required staged-fault isolation. Keep that boundary rather than introduce memory-only deduplication or new infrastructure.

No blocking business question remains. No migration or repair of already-corrupt historical snapshots is authorized. PostgreSQL, unique constraints, fsync/power loss and multiple writer processes are outside this fixture's acceptance.
