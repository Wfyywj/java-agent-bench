# Local regressions

Run from candidate/: `python3 regression-tests/test_returns.py`.

Requires Python 3 and Java 21 with `jdk.compiler`. Uses the installed compiler
module (`java -m jdk.compiler/com.sun.tools.javac.Main`), so a separate `javac`
launcher is unnecessary. No packages or network services are required. The suite
compiles supplied Java sources, launches the loopback server, makes independent
HTTP connections and inspects only temporary snapshots inside candidate/.
Temporary build/data directories are removed on completion. See
`../evidence-map.md` for B02-A01 through B02-A05 mapping and scope limits.
