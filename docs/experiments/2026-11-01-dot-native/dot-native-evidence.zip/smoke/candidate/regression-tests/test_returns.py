"""Own black-box regression suite; uses only public fixture inputs and Java sources.
Run: python3 regression-tests/test_returns.py
All build and snapshot files are temporary children of candidate/.
"""
import concurrent.futures
import http.client
from pathlib import Path
import select
import subprocess
import tempfile
import unittest
import urllib.parse

ROOT = Path(__file__).resolve().parents[1]


class Returns(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.build = tempfile.TemporaryDirectory(prefix='.regression-build-', dir=ROOT)
        subprocess.run(['java', '-m', 'jdk.compiler/com.sun.tools.javac.Main', '-d', cls.build.name, *map(str, sorted((ROOT / 'src').glob('*.java')))], check=True)

    @classmethod
    def tearDownClass(cls):
        cls.build.cleanup()

    def setUp(self):
        self.work = tempfile.TemporaryDirectory(prefix='.regression-data-', dir=ROOT)
        self.snapshot = Path(self.work.name) / 'snapshot.tsv'
        self.snapshot.write_bytes((ROOT / 'evidence/seed.tsv').read_bytes())
        self.proc = None
        self.start()

    def start(self):
        self.proc = subprocess.Popen(['java', '-Xmx96m', '-cp', self.build.name, 'App', str(self.snapshot)],
                                     stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if not select.select([self.proc.stdout], [], [], 10)[0]:
            self.stop()
            self.fail('Server did not report a port in 10 seconds')
        self.port = int(self.proc.stdout.readline())

    def stop(self):
        if self.proc is not None:
            self.proc.terminate()
            try:
                self.proc.communicate(timeout=10)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                self.proc.communicate()
            self.proc = None

    def restart(self):
        self.stop()
        self.start()

    def tearDown(self):
        self.stop()
        self.work.cleanup()

    def post(self, fault=0, **changes):
        data = dict(tenant='tenantA', loan='loan1', token='cabinet77', equipment='bat1', damaged='false')
        data.update(changes)
        conn = http.client.HTTPConnection('127.0.0.1', self.port, timeout=10)
        try:
            conn.request('POST', '/returns', urllib.parse.urlencode(data),
                         {'Content-Type': 'application/x-www-form-urlencoded', 'X-Test-Fault': str(fault)})
            reply = conn.getresponse()
            return reply.status, reply.read().decode()
        finally:
            conn.close()

    def rows(self):
        return [line.split('\t') for line in self.snapshot.read_text().splitlines()]

    def assert_counts(self, events, jobs):
        rows = self.rows()
        self.assertEqual(sum(r[0] == 'E' for r in rows), events)
        self.assertEqual(sum(r[0] == 'C' for r in rows), jobs)

    def assert_state(self, loan, state):
        self.assertEqual(next(r[4] for r in self.rows() if r[0:2] == ['L', loan]), state)

    def test_A01_durable_replay_and_second_token(self):
        expected = (200, 'loan=loan1;state=CLEANING')
        self.assertEqual(self.post(), expected)
        committed = self.snapshot.read_bytes()
        self.assertEqual(self.post(), expected)
        self.restart()
        self.assertEqual(self.post(), expected)
        self.assertEqual(self.post(token='new-token'), (409, 'NOT_RETURNABLE'))
        self.assertEqual(self.snapshot.read_bytes(), committed)
        self.assert_counts(1, 1)
        self.assert_state('loan1', 'CLEANING')

    def test_A02_payload_conflicts(self):
        self.assertEqual(self.post()[0], 200)
        committed = self.snapshot.read_bytes()
        for restart in (False, True):
            if restart:
                self.restart()
            for changes in ({'equipment': 'ball2'}, {'damaged': 'true'},
                            {'loan': 'loan2', 'equipment': 'ball2'}):
                with self.subTest(restart=restart, changes=changes):
                    self.assertEqual(self.post(**changes), (409, 'TOKEN_CONFLICT'))
                    self.assertEqual(self.snapshot.read_bytes(), committed)

    def test_A03_each_stage_rolls_back_and_retries(self):
        for damaged in ('false', 'true'):
            for stage in (1, 2, 3):
                with self.subTest(damaged=damaged, stage=stage):
                    self.stop()
                    self.snapshot.write_bytes((ROOT / 'evidence/seed.tsv').read_bytes())
                    self.start()
                    before = self.snapshot.read_bytes()
                    self.assertEqual(self.post(fault=stage, damaged=damaged), (503, 'RETRY_LATER'))
                    self.assertEqual(self.snapshot.read_bytes(), before)
                    # In-memory state also remains unchanged: another failed attempt must reach its fault.
                    self.assertEqual(self.post(fault=stage, damaged=damaged), (503, 'RETRY_LATER'))
                    self.restart()
                    self.assertEqual(self.snapshot.read_bytes(), before)
                    state = 'REVIEW' if damaged == 'true' else 'CLEANING'
                    expected = (200, 'loan=loan1;state=' + state)
                    self.assertEqual(self.post(damaged=damaged), expected)
                    self.assert_counts(1, 0 if damaged == 'true' else 1)
                    self.assert_state('loan1', state)
                    self.restart()
                    self.assertEqual(self.post(damaged=damaged), expected)

    def test_A03_retry_without_restart(self):
        for stage in (1, 2, 3):
            with self.subTest(stage=stage):
                self.stop()
                self.snapshot.write_bytes((ROOT / 'evidence/seed.tsv').read_bytes())
                self.start()
                before = self.snapshot.read_bytes()
                self.assertEqual(self.post(fault=stage), (503, 'RETRY_LATER'))
                self.assertEqual(self.snapshot.read_bytes(), before)
                self.assertEqual(self.post(), (200, 'loan=loan1;state=CLEANING'))
                self.assert_counts(1, 1)
                self.assert_state('loan1', 'CLEANING')

    def test_A04_tenant_nondisclosure_and_lifecycle(self):
        before = self.snapshot.read_bytes()
        for changes in ({'tenant': 'tenantB'}, {'loan': 'missing'},
                        {'loan': 'loan3', 'equipment': 'mat3'}):
            self.assertEqual(self.post(**changes), (404, 'NOT_FOUND'))
        for loan, equipment in [('loan4', 'cone4'), ('loan5', 'net5')]:
            self.assertEqual(self.post(loan=loan, equipment=equipment), (409, 'NOT_RETURNABLE'))
        self.restart()
        self.assertEqual(self.snapshot.read_bytes(), before)
        self.assert_counts(0, 0)

    def test_A04_wrong_equipment_does_not_bind_token(self):
        for damaged in ('false', 'true'):
            with self.subTest(damaged=damaged):
                self.stop()
                self.snapshot.write_bytes((ROOT / 'evidence/seed.tsv').read_bytes())
                self.start()
                before = self.snapshot.read_bytes()
                self.assertEqual(self.post(equipment='ball2', damaged=damaged), (409, 'NOT_RETURNABLE'))
                self.assertEqual(self.snapshot.read_bytes(), before)
                self.restart()
                self.assertEqual(self.snapshot.read_bytes(), before)
                self.assertEqual(self.post(equipment='ball2', damaged=damaged), (409, 'NOT_RETURNABLE'))
                state = 'REVIEW' if damaged == 'true' else 'CLEANING'
                expected = (200, 'loan=loan1;state=' + state)
                self.assertEqual(self.post(damaged=damaged), expected)
                committed = self.snapshot.read_bytes()
                self.restart()
                self.assertEqual(self.post(damaged=damaged), expected)
                self.assertEqual(self.snapshot.read_bytes(), committed)
                self.assert_state('loan1', state)
                self.assert_counts(1, 0 if damaged == 'true' else 1)

    def test_A05_concurrent_normal_and_damaged(self):
        import threading
        for loan, equipment, damaged, state in [('loan1', 'bat1', 'false', 'CLEANING'),
                                               ('loan2', 'ball2', 'true', 'REVIEW')]:
            barrier = threading.Barrier(2)
            def submit():
                barrier.wait(timeout=10)
                return self.post(loan=loan, equipment=equipment, token=loan, damaged=damaged)
            with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
                results = list(pool.map(lambda _: submit(), range(2)))
            self.assertEqual(results, [(200, f'loan={loan};state={state}')] * 2)
            self.assert_state(loan, state)
        self.assert_counts(2, 1)
        committed = self.snapshot.read_bytes()
        self.restart()
        self.assertEqual(self.post(loan='loan2', equipment='ball2', token='loan2', damaged='true'),
                         (200, 'loan=loan2;state=REVIEW'))
        self.assertEqual(self.post(loan='loan2', equipment='ball2', token='another', damaged='true'),
                         (409, 'NOT_RETURNABLE'))
        self.assertEqual(self.snapshot.read_bytes(), committed)

    def test_A01_A04_token_scope_and_ownership_before_replay(self):
        self.assertEqual(self.post()[0], 200)
        committed = self.snapshot.read_bytes()
        self.assertEqual(self.post(loan='loan3', equipment='mat3'), (404, 'NOT_FOUND'))
        self.assertEqual(self.post(loan='unknown'), (404, 'NOT_FOUND'))
        self.assertEqual(self.snapshot.read_bytes(), committed)
        self.assertEqual(self.post(tenant='tenantB', loan='loan3', equipment='mat3'),
                         (200, 'loan=loan3;state=CLEANING'))
        self.assert_counts(2, 2)
        self.restart()
        self.assertEqual(self.post(tenant='tenantB', loan='loan3', equipment='mat3'),
                         (200, 'loan=loan3;state=CLEANING'))
        self.assert_counts(2, 2)


if __name__ == '__main__':
    unittest.main(verbosity=2)
