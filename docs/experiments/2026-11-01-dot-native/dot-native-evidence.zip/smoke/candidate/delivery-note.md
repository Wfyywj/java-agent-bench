# Delivery note

## Change

Changed only `src/ReturnService.java` in the Java implementation. Durable event
lookup now returns the original response for an exact payload and TOKEN_CONFLICT
for a changed owned-loan payload. First returns require BORROWED and matching
equipment. Existing synchronization, staging, snapshot serialization, API and
error strings remain intact. This prevents event overwrite/duplicate cleaning
jobs and permits damaged REVIEW replay after restart.

Added `requirement-decisions.md`, `evidence-map.md`,
`regression-tests/test_returns.py`, `regression-tests/README.md`, and this note.
Public input files and the other Java files are unchanged (verified against the
supplied PREPARED.json hashes).

## Validation performed

- Java runtime: OpenJDK 21.0.12.1. Python standard-library HTTP tests only.
- `python3 regression-tests/test_returns.py`: final run **8 tests passed**, 19.191s.
  Covers B02-A01 through A05, including restart, complete snapshot invariance on
  errors, six staged-fault paths, immediate retry, tenant token scope, wrong
  equipment correction, and concurrent normal/damaged requests.
- Earlier seven-test suite also passed. The initial compile attempt failed
  because `javac` is absent from PATH; the final suite successfully compiles using
  the installed `jdk.compiler` module through `java -m` instead. No install used.
- SHA-256 comparison confirmed preservation of all supplied public inputs and
  unchanged Java files. No benchmark selfcheck, verifier, reference, diagnostic
  mutants, connected apps, network, or external solution was used.

## Rollback

Stop the sole writer before rollback. Restore the previous ReturnService.java
from the deployment's source revision, rebuild, and restart against the existing
snapshot: there is no data-format migration. Preserve a snapshot backup before
any deployment/rollback. Reverting the fix reintroduces duplicate-return risk;
prefer keeping returns paused until a corrected build is available. Do not
restore an old snapshot over newer successful returns. Historical duplicate
jobs, if any, need a separately authorized reconciliation rather than automatic
deletion by this patch.

## Unverified / intentionally excluded

No PostgreSQL execution, database uniqueness/transactions, two DB connections,
fsync or abrupt power-loss guarantees, multiprocess writers, historical data
repair, corrupt snapshots, or production authentication was tested. Restart
checks use process termination after committed responses, not crash-window fault
injection. Fault tests exercise the provided staged-write hooks, not physical
filesystem failures. Concurrency evidence is two barrier-coordinated HTTP clients
in the one-service adapter, not a sustained load test. A03/A05 are partial local
adapter acceptance only. Full catalog infrastructure acceptance is not claimed.
