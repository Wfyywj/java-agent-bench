# Evidence map

All supplied evidence is synthetic/public; observations below are local tests,
not benchmark or production acceptance.

| Evidence | Observation and design consequence |
|---|---|
| `evidence/incident.log` | Same cabinet token retried after response loss; two jobs, one event. Repair must prevent repeated side effects, not just overwrite the event. |
| `evidence/seed.tsv` | Two tenantA BORROWED loans, one tenantB BORROWED loan, AVAILABLE and RETIRED loans. Used unchanged as initial state for each regression. |
| `evidence/schema.sql` | Planned event uniqueness by tenant/token and cleaning uniqueness by loan, with joint transaction. Motivates complete payload binding and one publication; no SQL execution is claimed. |
| Original `src/ReturnService.java` | Read `previous` but never used it; allowed CLEANING to return again. Explains event overwrite and repeated list append. REVIEW replay was rejected. |
| `src/Store.java` | Events persist full payload/result; copied staging and atomic file rename already exist. Preserve this repository boundary rather than inventing a cache. |
| `src/App.java` | One shared service, four worker threads, independent HTTP clients, exception-to-503 mapping. Synchronization must cover the whole service operation. |

## Regression-to-acceptance mapping

Run `python3 regression-tests/test_returns.py` from candidate/. Each test starts
real loopback HTTP, inspects the durable snapshot, and uses only public sources.

| Criterion | Regression methods | Assertions |
|---|---|---|
| B02-A01 | `test_A01_durable_replay_and_second_token`; `test_A01_A04_token_scope_and_ownership_before_replay` | Exact response and unchanged bytes on replay before/after restart; one event/job; CLEANING persists; fresh token rejected; same token independent across tenants. |
| B02-A02 | `test_A02_payload_conflicts` | Equipment, damage and owned-loan changes conflict before/after restart; complete snapshot unchanged. |
| B02-A03 | `test_A03_each_stage_rolls_back_and_retries`; `test_A03_retry_without_restart` | All three faults, both normal and damaged paths: 503, byte-identical snapshot, repeat failure, restart, successful retry with/without restart and durable replay; expected state/event/job counts. |
| B02-A04 | `test_A04_tenant_nondisclosure_and_lifecycle`; `test_A04_wrong_equipment_does_not_bind_token`; token-scope test | Foreign/unknown loans return identical 404; AVAILABLE/RETIRED and wrong equipment rejected; no changes across restart; corrected same-token requests succeed and replay durably for both damage flags. |
| B02-A05 | `test_A05_concurrent_normal_and_damaged` | Barrier-coordinated independent HTTP connections return identical success; one event per loan, one normal job, no damaged job; REVIEW persists/replays after restart and rejects another token. |

A03 and A05 are local-adapter evidence, **not full catalog infrastructure acceptance**.
