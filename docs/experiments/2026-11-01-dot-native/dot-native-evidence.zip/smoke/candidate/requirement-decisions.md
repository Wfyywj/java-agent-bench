# Requirement decisions

## Provided business answers (not inferred)

The frozen contract in `PROMPT.md` defines the endpoint and response strings,
tenant-scoped tokens binding loan/equipment/damage, durable exact replay, conflict
on changed payload, indistinguishable tenant/unknown-loan failures, and rejection
of wrong equipment and non-borrowed items. Normal returns enter CLEANING with
one job. Damaged returns enter REVIEW without a job or automatic availability.
All three writes must publish together; injected failures return 503 with no
effects. Two independent clients are supported by one process/writer.

## Implementation decisions and explicit assumptions

- Preserve ownership validation before token lookup. If a changed loan is foreign
  or unknown, 404 takes precedence over token conflict, so tokens cannot reveal
  another tenant's loan. Changed payload for a known owned loan returns 409
  TOKEN_CONFLICT. This precedence reconciles the two provided requirements;
  it is an explicit interpretation, not an additional supplied business answer.
- Check an existing event before lifecycle/equipment validation. Exact replay is
  read-only even when the loan is now CLEANING or REVIEW; return the stored result,
  not a result recomputed from the new request.
- Without an existing event, only BORROWED and correctly bound equipment may
  transition. A fresh token cannot repeat a completed return. Validation errors
  never consume a token, so correcting a rejected first request works.
- Retain `ReturnService.submit` synchronization across validation, snapshot
  staging, and commit. The supplied App constructs exactly one service and Store;
  supporting multiple service instances/writers is outside the given adapter.
- Retain Store's durable event representation and atomic snapshot replacement.
  All changes are staged in a copied Store. In-memory publication occurs only
  after file replacement. No in-memory-only replay cache or format migration.
- Treat the supplied seed and snapshots as trusted adapter data. This repair does
  not migrate pre-existing duplicate jobs, add input schema recovery, or change
  the HTTP parser. No clarification was needed for the specified workflow.

## Boundary and limits

The service owns business validation and write ordering; Store owns snapshot
serialization and publication; App owns HTTP/error translation. The planned SQL
schema describes a future `(tenant, token)` event primary key and a per-loan
cleaning primary key within a DB transaction. It is not executed here. Local
synchronization plus atomic replacement is evidence only for this single-writer
adapter, not PostgreSQL uniqueness, multiprocess safety, or power-loss durability.
